# RA1. Arquitectura inicial del proyecto

## Objetivo del proyecto

Desarrollar un juego de tres en raya en Java como proyecto de 2º de Desarrollo de Aplicaciones Multiplataforma. La aplicación tendrá una interfaz de usuario, distintos niveles de inteligencia artificial y un historial de partidas.

En este primer paso se prepara únicamente la arquitectura del proyecto. Las clases creadas son esqueletos y no contienen todavía la lógica del juego.

## Estructura Maven

El proyecto utiliza la estructura estándar de Maven:

- `src/main/java`: código fuente de la aplicación.
- `src/test/java`: pruebas automatizadas que se añadirán en fases posteriores.
- `pom.xml`: configuración del proyecto Maven, sus coordenadas y la versión de Java.

El paquete raíz es `com.tresenraya`.

## Función de cada paquete

- `com.tresenraya`: punto de entrada de la aplicación.
- `com.tresenraya.modelo`: entidades y conceptos principales del dominio del juego.
- `com.tresenraya.interfaz`: ventanas de la aplicación.
- `com.tresenraya.interfaz.componentes`: componentes visuales reutilizables de las ventanas.
- `com.tresenraya.ia`: estrategias de inteligencia artificial y sus niveles de dificultad.
- `com.tresenraya.persistencia`: almacenamiento y representación del historial de partidas.
- `com.tresenraya.configuracion`: opciones y parámetros generales de la aplicación.
- `com.tresenraya.util`: constantes y utilidades comunes.

## Función prevista de cada grupo de clases

### Aplicación

- `App`: es el único punto de entrada de la aplicación. Su método `main` utiliza `SwingUtilities.invokeLater` para crear y mostrar `VentanaInicio` en el Event Dispatch Thread. No contiene reglas del juego.

### Modelo

- `Partida`: mantiene el tablero `char[][]` de 3x3, el turno actual, los movimientos realizados, el ganador y el empate. También aplica las reglas principales, valida las jugadas y detecta las ocho combinaciones ganadoras.
- `Jugador`: representa a un participante mediante su nombre, su símbolo `X` u `O` y si es humano o IA.
- `Movimiento`: representa una jugada mediante la fila, la columna y el jugador que la realizó.
- `Dificultad`: enumera los niveles `FACIL`, `MEDIA` y `DIFICIL` que utilizará la inteligencia artificial.

El paquete `modelo` no depende de `javax.swing` ni de `java.awt`, por lo que sus clases pueden utilizarse y probarse sin abrir ninguna ventana.

Las pruebas del modelo se encuentran en `src/test/java/com/tresenraya/modelo`. JUnit no está configurado en Maven, así que se utiliza un arnés Java autocontenido (`ModeloTest`) con aserciones que detienen la ejecución si falla una comprobación.

### Pruebas realizadas

Se comprobaron los siguientes casos:

- X gana por fila.
- X gana por columna.
- X gana por diagonal.
- O gana.
- Empate.
- Rechazo de una casilla ocupada.
- Cambio de turnos.
- Número de movimientos realizados.
- Reinicio de una partida, incluyendo tablero, turno, ganador y contador.
- Creación de jugadores humanos y de IA.
- Registro de fila, columna y jugador en los movimientos.
- Disponibilidad de `Dificultad.FACIL`, `Dificultad.MEDIA` y `Dificultad.DIFICIL`.
- Las ocho combinaciones ganadoras del tablero.

### Resultado de las pruebas

El comando `mvn test -B` terminó con `BUILD SUCCESS` y compiló el modelo y el arnés. Como `ModeloTest` no utiliza JUnit, Surefire informó `Tests run: 0`.

La ejecución directa del arnés con `java -ea` produjo exactamente `Pruebas del modelo superadas`. Por tanto, todas las comprobaciones enumeradas anteriormente pasaron correctamente.

### Interfaz

- `VentanaInicio`: es la ventana principal de entrada. Muestra `Nueva partida`, `Cargar partida`, `Configuración` y `Salir`. Mantiene una única `Configuracion`, abre `VentanaConfiguracion` para editar los nombres y encamina cada partida por `VentanaModoJuego`. Incluye mnemonics de teclado y un botón predeterminado.
- `VentanaConfiguracion`: permite editar únicamente los nombres de X y O mediante campos Swing. Al guardar modifica la instancia compartida de `Configuracion`; no contiene reglas ni lógica de IA.
- `VentanaJuego`: coordina la partida en curso con un `ModoJuego` explícito. En modo local crea dos jugadores humanos; contra IA crea una estrategia únicamente para O. Muestra el modo, los nombres, la dificultad cuando corresponde, el turno y el resultado. Al pulsar una casilla delega la jugada en `Partida.marcar(...)` y `actualizarVista()` refleja el estado que devuelve el modelo. No contiene comprobaciones de victorias ni decide el ganador.

El flujo es `App -> VentanaInicio -> Nueva partida -> VentanaModoJuego`. El modo `JUGADOR_VS_JUGADOR` inicia una partida con dos jugadores humanos y sin estrategia de IA. El modo `JUGADOR_VS_IA` abre `VentanaDificultad`; la elección se pasa a `VentanaJuego` y selecciona `IaFacil`, `IaMedia` o `IaDificil`. `VentanaConfiguracion` edita únicamente los nombres guardados en `Configuracion`; el modo y la dificultad se seleccionan para cada partida.

`PanelTablero` muestra una copia del estado proporcionado por `Partida.tablero()`. `VentanaJuego` no lee los textos de los botones para decidir resultados: consulta `Partida.haTerminado()`, `Partida.ganador()` y `Partida.hayEmpate()`. La lógica de turnos, movimientos, victorias y empates permanece en `Partida` para mantener el modelo independiente de Swing.
- `VentanaModoJuego`: permite elegir `JUGADOR_VS_JUGADOR` o `JUGADOR_VS_IA` para la nueva partida. Su acción Volver regresa a Inicio.
- `VentanaDificultad`: se abre solo al elegir Jugador vs IA y permite elegir entre Fácil, Media y Difícil. Utiliza el enum `com.tresenraya.modelo.Dificultad` para representar la opción, comunica la selección mediante un callback `Consumer<Dificultad>` y permite volver al selector de modo. No contiene reglas ni implementa la IA; las estrategias pertenecen exclusivamente al paquete `ia`.
- `PanelTablero`: representa exclusivamente el tablero 3x3 mediante una matriz `JButton[][]` y `GridLayout(3, 3)`. Las casillas se crean mediante bucles y el componente solo muestra los símbolos que recibe.
- `PanelInformacion`: muestra el modo de juego, los nombres, el turno actual, el número de jugadas y el resultado mediante etiquetas; incluye la dificultad solo en modo Jugador vs IA. Recibe datos ya calculados y no contiene reglas del juego.

`PanelTablero` y `PanelInformacion` se separan de `VentanaJuego` para mantener componentes visuales pequeños y reutilizables. `VentanaJuego` podrá coordinar ambos componentes y comunicarse con el modelo, mientras cada panel se concentra en una única responsabilidad de presentación.

La prueba `PanelesTest` comprobó que el tablero utiliza `GridLayout(3, 3)`, contiene nueve botones creados mediante bucles y muestra correctamente los símbolos. También comprobó que `PanelInformacion` muestra el turno actual, el número de jugadas y el resultado.

La ejecución directa produjo exactamente `Pruebas de paneles superadas`. Además, `mvn test -B` terminó con `BUILD SUCCESS`; Surefire informó `Tests run: 0` porque estas pruebas son arneses Java con `main`, no pruebas JUnit.

La prueba `VentanaJuegoTest` realizó una partida completa mediante cinco pulsaciones sobre las casillas del tablero. Comprobó que `Partida` terminó con Ana como ganadora, que se registraron cinco movimientos, que los símbolos aparecieron en `PanelTablero` y que `PanelInformacion` mostró `Resultado: Gana Ana (X)`. El resultado real fue `Prueba de partida completa superada`.

## Paso 7: juego básico entre dos personas

El botón `Nueva partida` de `VentanaInicio` crea `VentanaJuego` a partir de la `Configuracion` actual. En `VentanaJuego`, cada botón del `PanelTablero` conserva sus coordenadas mediante el listener registrado al construir el tablero y llama a `alPulsarCasilla(fila, columna)`.

`alPulsarCasilla` delega en `partida.marcar(fila, columna)` y, después, llama a `actualizarVista()`. Este último método obtiene el tablero, el turno, el contador, el ganador y el empate desde `Partida`; nunca decide el resultado leyendo los textos de los botones. El botón `Nueva partida` inicia una partida nueva y devuelve el turno a X. El botón `Volver al inicio` cierra la ventana de juego y restaura el menú.

La prueba real `VentanaJuegoTest` comprobó el flujo por selector de modo, las partidas local y contra IA, la presencia del tablero 3x3, la alternancia de X y O, las tres dificultades, victorias, el bloqueo de movimientos posteriores, empates, reinicio, nombres, historial y carga de partidas. Las pruebas de JUnit 5 también verifican alternancia y persistencia de nombres en el modo local, respuesta de cada IA y navegación de regreso desde la dificultad al selector de modo.

### Punto de entrada original (Paso 13)

`com.tresenraya.App` contiene el único método `main` del código principal. El método inicia la interfaz con `SwingUtilities.invokeLater(() -> new VentanaInicio().setVisible(true))`. `App` solo inicia la aplicación; la selección de dificultad, la creación de jugadores, las reglas y la IA pertenecen a sus respectivas capas.

## Paso 12: accesibilidad mediante teclado

La interfaz mantiene un orden de foco lógico basado en el orden de los componentes de cada layout. `VentanaInicio` recorre `Nueva partida`, `Cargar partida`, `Configuración` y `Salir`; `VentanaJuego` recorre las nueve casillas de izquierda a derecha y de arriba abajo antes de sus botones inferiores; los formularios siguen el orden etiqueta/campo y selector/acciones.

Las casillas del tablero son botones focusables, conservan sus coordenadas en el `actionCommand` y tienen nombre y descripción accesibles. El foco se pinta explícitamente en botones y las ventanas utilizan una política de foco basada en layouts. Se añadieron mnemonics: `Alt+N`, `Alt+A`, `Alt+C`, `Alt+S` en Inicio; `Alt+F`, `Alt+M`, `Alt+D` en dificultad; `Alt+G`, `Alt+V` en configuración; `Alt+V` para `Ver partida`; y `Alt+N`, `Alt+S` en Juego.

El turno y el resultado continúan mostrándose mediante texto en `PanelInformacion` (`Turno actual`, `Jugadas`, `Ganador` o `Empate`), sin depender únicamente del color. `AccesibilidadTest` comprobó el orden de controles, foco visible, acceso a las nueve casillas, mnemonics, lista de historial y controles de configuración. La ejecución real produjo `Pruebas de accesibilidad superadas`.

El tablero también funciona como una cuadrícula de teclado: `VentanaJuego` mantiene `filaSeleccionada` y `columnaSeleccionada`, limita sus valores a 0..2 y utiliza `InputMap`/`ActionMap` para mover el cursor con las flechas. `PanelTablero.actualizarSeleccion()` marca la casilla con un borde visible, incluso si contiene X u O. Espacio llama al mismo `alPulsarCasilla(fila, columna)` que utiliza el ratón, por lo que `Partida` sigue validando las casillas ocupadas y todas las reglas.

La selección comienza en la esquina superior izquierda, se reinicia al comenzar una partida y permanece disponible después de cada movimiento y de la respuesta de la IA. `VentanaPartidaCargada` no instala estos controles de juego y mantiene sus casillas deshabilitadas. `TecladoTableroTest` utilizó `java.awt.Robot` sobre ventanas visibles para probar flechas, límites, Espacio, una partida completa con victoria, una partida completa en empate, rechazo de casilla ocupada, respuesta de IA y solo lectura. El resultado real fue `Pruebas reales de teclado del tablero superadas`.

La aplicación `com.tresenraya.App` también se ejecutó directamente; el proceso permaneció activo sin excepciones con la ventana inicial abierta. `mvn test -B` terminó con `BUILD SUCCESS`. Surefire informa `Tests run: 0` porque las pruebas actuales son arneses Java con `main`; su ejecución efectiva se realiza directamente con `java`.

La selección de dificultad se mantiene separada por responsabilidades: `VentanaDificultad` presenta las opciones y comunica la elegida; `Dificultad` pertenece al modelo y define los valores posibles; las estrategias de `ia` implementan el comportamiento de cada nivel.

La prueba `VentanaDificultadTest` pulsa los botones Swing `Fácil`, `Media` y `Difícil`, y comprueba que el callback recibe respectivamente `Dificultad.FACIL`, `Dificultad.MEDIA` y `Dificultad.DIFICIL`.

El resultado real de la ejecución directa fue: `Pruebas de VentanaDificultad superadas`. Además, `mvn test -B` terminó con `BUILD SUCCESS`; Surefire informó `Tests run: 0` porque las pruebas del proyecto son arneses Java con `main`, no pruebas JUnit.

### Inteligencia artificial

- `InteligenciaArtificial`: define el método `decidirMovimiento(Partida)`, que permite solicitar una propuesta de jugada sin acoplar la IA a la interfaz.
- `IaFacil`: elige aleatoriamente una casilla libre, sin buscar tácticas avanzadas.
- `IaMedia`: intenta ganar en una jugada, bloquear una victoria rival y después prioriza centro, esquinas y casillas restantes.
- `IaDificil`: utiliza minimax para valorar las jugadas posibles y buscar una decisión óptima dentro de las reglas del Tres en Raya.

La IA recibe una `Partida`, consulta su tablero y su turno actual y devuelve un `Movimiento`. La aplicación que coordine la partida debe aplicar esa propuesta mediante `Partida.marcar(fila, columna)`. La IA no modifica directamente el tablero ni contiene la lógica oficial de validación, turnos, victorias o empates.

La interfaz no contiene la lógica de IA porque su responsabilidad es presentar controles y solicitar movimientos. Así se puede cambiar una estrategia o probarla sin mezclar algoritmos con Swing; `Partida` sigue siendo la única responsable de aceptar o rechazar jugadas y de calcular el estado final.

La prueba `IaTest` comprobó las tres dificultades sin utilizar Swing: `IaFacil` eligió una casilla libre, `IaMedia` ganó cuando pudo y bloqueó una victoria rival, e `IaDificil` priorizó el centro y eligió una victoria inmediata. La ejecución real produjo `Pruebas de IA superadas`.

## Paso 8: jugador humano contra IA

El flujo de configuración es `VentanaInicio -> Configuración -> Guardar`. `VentanaInicio` conserva la instancia de `Configuracion` mientras el usuario navega. Al pulsar `Nueva partida`, `VentanaModoJuego` comunica el modo. En Jugador vs Jugador la dificultad no se solicita y ambos nombres corresponden a personas; en Jugador vs IA se abre `VentanaDificultad` y se crea la estrategia elegida junto con los nombres configurados.

En una partida contra la máquina, `VentanaJuego` crea `Jugador` humano con símbolo `X`, `Jugador` máquina con símbolo `O` y selecciona la implementación correspondiente mediante `InteligenciaArtificial`: `IaFacil`, `IaMedia` o `IaDificil`. La ventana no contiene el algoritmo de ninguna dificultad.

Cuando el usuario pulsa una casilla, `VentanaJuego.alPulsarCasilla(...)` comprueba el estado y el turno humano, llama a `Partida.marcar(...)` y actualiza la vista. Si `Partida` indica que continúa y el turno es de O, solicita a la IA un `Movimiento`; después aplica sus coordenadas mediante `Partida.marcar(...)`. La IA nunca modifica directamente el `char[][]` ni los botones.

Durante la decisión de la máquina se deshabilitan las casillas. Al terminar, `actualizarVista()` vuelve a habilitar únicamente las casillas libres si la partida continúa. Los resultados se leen del modelo y se muestran como `Ganador: X`, `Ganador: O` o `Empate`.

El botón `Nueva partida` crea una nueva `Partida` con los mismos jugadores humano y máquina, conserva la dificultad y devuelve el turno a X. El botón `Volver al inicio` devuelve al menú principal; `Salir` en el menú cierra la aplicación.

La prueba real `VentanaJuegoTest` verificó el flujo de selección de Fácil, las tres dificultades, la respuesta automática de O tras una jugada de X, el reinicio conservando la dificultad, una victoria, un empate, el bloqueo tras terminar y el cierre. El resultado observado fue `Pruebas completas del juego superadas`. `IaTest` verificó además los comportamientos diferenciados de Fácil, Media y Difícil, con resultado `Pruebas de IA superadas`.

### Persistencia

- `Historial`: define las operaciones `guardar`, `cargarPartidas` y `obtenerHistorial` para trabajar con resultados.
- `HistorialConsola`: mantiene resultados temporalmente en memoria y muestra cada resultado por consola como implementación de prueba.
- `HistorialFichero`: crea, escribe y lee `historial.txt` utilizando las clases estándar `Files`, `Path` y UTF-8. También reconstruye los movimientos guardados.
- `PartidaGuardada`: relaciona un `ResultadoPartida` con su lista inmutable y ordenada de `Movimiento`, sin añadir campos al resultado original.
- `VentanaPartidaCargada`: reconstruye y muestra el tablero final de una partida terminada. Sus casillas están deshabilitadas y no permite continuar ni modificar la partida.
- `ResultadoPartida`: representa una partida terminada con exactamente los campos `jugadorX`, `jugadorO`, `ganador`, `numeroMovimientos` y `fecha`.

Cuando una partida termina, `VentanaJuego` crea un `ResultadoPartida` a partir del estado de `Partida` y lo entrega a `Historial`. La persistencia no está dentro de `Partida` ni de los componentes visuales; la ventana solo coordina el uso del servicio de historial.

La separación permite que el modelo gestione únicamente reglas y estado, que la interfaz gestione eventos y representación, y que persistencia gestione el almacenamiento de resultados. En el futuro se podrá sustituir `HistorialConsola` por otra implementación sin modificar las reglas del juego.

El fichero se guarda en la carpeta de ejecución como `historial.txt`, fuera de `src/main/java`. Cada línea contiene los nombres de X y O, el ganador, el número de movimientos y la fecha ISO separados por `|`, seguidos opcionalmente por los movimientos serializados como `fila,columna,simbolo;...`. Solo se guarda el resultado final y su secuencia completa de movimientos, nunca una partida en curso. Las líneas antiguas de cinco secciones siguen cargándose; se muestran sus datos, pero se indica que no hay movimientos suficientes para reconstruir el tablero.

`VentanaInicio` ofrece el botón `Cargar partida`, que abre `VentanaHistorial`. Esta ventana pide las partidas a `Historial`, muestra una lista con ganador, movimientos y fecha, y permite seleccionar una entrada para consultar también los jugadores X y O. Al seleccionar una entrada se habilita `Ver partida`, que abre `VentanaPartidaCargada`. Esta ventana aplica los `Movimiento` en orden sobre un tablero vacío y muestra el estado final en modo solo lectura. Cargar una partida no inicia una partida nueva ni permite modificar el historial. La interfaz no accede directamente a `historial.txt`.

El mensaje de guardado conserva exactamente el formato `Partida guardada: Ganador: X, movimientos: 9, fecha: 2026-09-25T10:07:19.086659700` (cambiando ganador, movimientos y fecha según el resultado real).

La prueba `PersistenciaTest` guardó un resultado real y verificó los cinco campos. La ejecución mostró `Partida guardada: Ganador: X, movimientos: 5, fecha: 2026-09-25T10:00` en la prueba de consola y produjo `Prueba de persistencia superada`. `HistorialFicheroTest` creó un fichero temporal, guardó un empate, creó una segunda instancia y lo cargó correctamente, produciendo `Prueba de persistencia en fichero superada`. `VentanaHistorialTest` seleccionó y mostró una partida, produciendo `Prueba de consulta de historial superada`.

`HistorialFicheroResultadosTest` guardó en una misma ejecución una victoria de X, una victoria de O y un empate. Comprobó que el fichero contenía tres líneas y que una nueva instancia recuperaba los tres resultados. La ejecución real produjo `Pruebas de victorias y empate en fichero superadas`.

`PersistenciaJuegoTest` jugó una partida real de siete movimientos mediante `VentanaJuego`, cerró la ventana, abrió una nueva instancia de `HistorialFichero` y verificó el ganador y el último movimiento guardado. La ejecución real produjo `Prueba de partida completa persistida superada`. `VentanaPartidaCargadaTest` comprobó las posiciones finales exactas y que las nueve casillas quedaran deshabilitadas, produciendo `Prueba de reconstrucción de tablero superada`.

### Configuración y utilidades

- `Configuracion`: centraliza los datos generales de los jugadores X y O. La dificultad no se guarda aquí: corresponde a cada partida y la gestiona `VentanaDificultad`.
- `Constantes`: centraliza únicamente `TAMANO_TABLERO`, utilizado por el modelo y los componentes del tablero, y `TITULO_APLICACION`, compartido por las ventanas principales. No contiene lógica del juego ni valores que solo se utilicen en una clase.

El paquete `configuracion` evita que los datos generales de los jugadores se dispersen entre ventanas, el modelo y la IA. `Configuracion` almacena los nombres; no crea componentes Swing, no aplica reglas de `Partida` y no decide movimientos de inteligencia artificial. `VentanaConfiguracion` es la capa visual que edita esos nombres. La dificultad se elige para cada partida en `VentanaDificultad` y se entrega directamente a `VentanaJuego`. `ConfiguracionTest` comprueba los datos generales de los jugadores y el modo configurado.

## Motivo de la separación por responsabilidades

Separar las responsabilidades permite que cada paquete y cada grupo de clases tenga un propósito claro. Así se facilita la comprensión del código, el mantenimiento y la evolución del proyecto.

Esta organización también reduce el acoplamiento entre la lógica del dominio, la interfaz, la IA y la persistencia. Por ejemplo, será posible cambiar la forma de mostrar la partida sin modificar el modelo, o añadir una estrategia de IA sin mezclarla con las ventanas.

## Paso 13: integración completa y punto de entrada

`com.tresenraya.App` es el único punto de entrada (`main`) del código principal. Su responsabilidad se limita a programar la creación y visualización de `VentanaInicio` en el Event Dispatch Thread mediante `SwingUtilities.invokeLater`; no contiene reglas, lógica de IA, movimientos ni persistencia.

El flujo de inicio es `App -> VentanaInicio -> VentanaModoJuego`. Seleccionar Jugador vs Jugador crea la partida directamente, con dos participantes humanos que alternan turnos. Seleccionar Jugador vs IA abre `VentanaDificultad`; su elección determina una de las tres estrategias existentes. El botón Volver de dificultad regresa al selector de modo y el botón Volver de modo regresa a Inicio. Los modos y dificultad son propios de cada partida y no se almacenan en `Configuracion`, que conserva los nombres. Configuración e historial reutilizan ventanas abiertas, y los resultados continúan guardándose mediante el formato de persistencia existente sin descartar datos anteriores.

`Cargar partida` abre `VentanaHistorial` mediante el servicio `Historial` existente, respaldado en la aplicación por `HistorialFichero`. La acción `Ver partida` abre `VentanaPartidaCargada`, que reconstruye el tablero desde los movimientos guardados y mantiene todas las casillas deshabilitadas. Al terminar una partida, `VentanaJuego` consulta el estado de `Partida` y registra el resultado y sus movimientos una sola vez. El botón de la ventana de juego indica `Volver al inicio`; el botón `Salir` del menú cierra la aplicación. Los enlaces de las ventanas no trasladan reglas a la interfaz: `Partida` no depende de Swing ni de AWT.

El control del tablero utiliza bindings Swing tanto para el tablero como para sus botones focusables. Las flechas cambian la casilla seleccionada, Espacio activa la jugada seleccionada y el ratón conserva el mismo flujo de jugada. El arnés `TecladoTableroTest` utiliza `java.awt.Robot` para comprobar flechas, límites, Espacio, victoria, empate y respuesta de IA; su ejecución final pasó.

### Construcción y pruebas realizadas para este paso

- `mvn clean test`: terminó con `BUILD SUCCESS`.
- `mvn clean package`: terminó con `BUILD SUCCESS` y creó `target/tres-en-raya-1.0-SNAPSHOT.jar`.
- Ambos objetivos informaron cero tests ejecutados por Surefire: las clases existentes son arneses autocontenidos con `main`, no pruebas JUnit. Después de compilar con Maven se ejecutaron explícitamente los 14 arneses; todos pasaron, incluido el test con Robot y el flujo integral de inicio, configuración, las tres dificultades, historial y partida cargada.
- `java -cp target/classes com.tresenraya.App`: la aplicación se inició y permaneció en ejecución. Las pruebas automatizadas interactuaron con las ventanas y comprobaron las funciones; no se tomaron capturas ni se presenta esa ejecución como una inspección visual manual.
- La inspección confirmó un único `main`, paquetes coincidentes con las rutas, ausencia de dependencias Swing/AWT en `modelo`, y que la dificultad no se almacena en `Configuracion`. El `pom.xml` fija Java 17 mediante `maven.compiler.release` y UTF-8; no requiere dependencias adicionales.

Durante la integración se corrigió el flujo para evitar ventanas repetidas de configuración e historial y se mantuvo el retorno controlado al menú. El test de teclado detectó que el foco de un `JButton` podía interceptar el espacio y que reenfocar de forma asíncrona tras cada flecha no era necesario; se añadieron bindings explícitos de foco para las casillas y se conservó la selección lógica independiente del foco. Las ejecuciones posteriores del arnés de Robot pasaron. Surefire ejecutando cero tests no se interpreta como una ejecución satisfactoria de los arneses; por eso se lanzaron por separado.

La interfaz de Inicio se amplió y redistribuyó mediante layouts Swing: título centrado de 32 puntos, botones principales de 340 x 50 píxeles, mensaje inferior legible y atajos mostrados en varias columnas. La ventana se ajusta con `pack()`, queda centrada y se puede redimensionar sin estirar los botones fuera de su tamaño máximo. También se aumentó el tamaño de texto y controles en Configuración, Dificultad e Historial, y se ampliaron las ventanas de juego e historial de partida cargada. El tablero comparte casillas grandes con símbolos de mayor tamaño para facilitar la interacción con ratón y teclado.
