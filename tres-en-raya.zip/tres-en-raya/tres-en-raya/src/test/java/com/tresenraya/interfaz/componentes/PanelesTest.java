package com.tresenraya.interfaz.componentes;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;

public class PanelesTest {
    public static void main(String[] args) {
        comprobarPanelTablero();
        comprobarPanelInformacion();
        System.out.println("Pruebas de paneles superadas");
    }

    private static void comprobarPanelTablero() {
        PanelTablero panel = new PanelTablero();
        GridLayout layout = (GridLayout) panel.getLayout();

        comprobar(layout.getRows() == 3 && layout.getColumns() == 3, "El tablero no usa GridLayout 3x3");
        comprobar(panel.getComponentCount() == 9, "El tablero no tiene nueve casillas");
        comprobar(panel.getBoton(0, 0) instanceof JButton, "La casilla no es un JButton");

        panel.mostrarTablero(new char[][] {
            {'X', '\0', 'O'},
            {'\0', 'X', '\0'},
            {'O', '\0', 'X'}
        });
        comprobar("X".equals(panel.getBoton(0, 0).getText()), "No se mostró X en la casilla");
        comprobar("".equals(panel.getBoton(0, 1).getText()), "Una casilla vacía no quedó vacía");
        comprobar("O".equals(panel.getBoton(0, 2).getText()), "No se mostró O en la casilla");
    }

    private static void comprobarPanelInformacion() {
        PanelInformacion panel = new PanelInformacion();
        panel.actualizarTurno("Ana (X)");
        panel.actualizarNumeroJugadas(4);
        panel.mostrarResultado("Gana Ana");

        JLabel turno = panel.getEtiquetaTurno();
        JLabel jugadas = panel.getEtiquetaJugadas();
        JLabel resultado = panel.getEtiquetaResultado();
        comprobar("Turno actual: Ana (X)".equals(turno.getText()), "No se mostró el turno");
        comprobar("Jugadas: 4".equals(jugadas.getText()), "No se mostró el número de jugadas");
        comprobar("Resultado: Gana Ana".equals(resultado.getText()), "No se mostró el resultado");
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}