package com.tresenraya.persistencia;

import java.nio.file.Files;
import java.nio.file.Path;

import javax.swing.SwingUtilities;

import com.tresenraya.interfaz.VentanaJuego;
import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.Partida;

public class PersistenciaJuegoTest {
    public static void main(String[] args) throws Exception {
        Path fichero = Files.createTempFile("tres-en-raya-juego", ".txt");
        Files.deleteIfExists(fichero);
        try {
            Jugador jugadorX = new Jugador("Jugador X", 'X', true);
            Jugador jugadorO = new Jugador("Jugador O", 'O', true);
            HistorialFichero historial = new HistorialFichero(fichero);
            final VentanaJuego[] ventana = new VentanaJuego[1];
            SwingUtilities.invokeAndWait(() -> ventana[0] = new VentanaJuego(
                    new Partida(jugadorX, jugadorO), historial));

            int[][] jugadas = {
                {0, 0}, {1, 1}, {0, 1}, {2, 2}, {1, 0}, {2, 0}, {0, 2}
            };
            for (int[] jugada : jugadas) {
                SwingUtilities.invokeAndWait(() -> ventana[0].alPulsarCasilla(jugada[0], jugada[1]));
            }
            SwingUtilities.invokeAndWait(ventana[0]::dispose);

            HistorialFichero historialReabierto = new HistorialFichero(fichero);
            PartidaGuardada partida = historialReabierto.cargarPartidasDetalladas().get(0);
            comprobar(partida.getMovimientos().size() == 7, "No se guardaron los siete movimientos");
                comprobar(partida.getMovimientos().get(6).getFila() == 0
                    && partida.getMovimientos().get(6).getColumna() == 2,
                    "No se conservó el último movimiento");
            comprobar(partida.getResultado().getGanador().getSimbolo() == 'X',
                    "No se conservó el ganador X");
            System.out.println("Prueba de partida completa persistida superada");
        } finally {
            Files.deleteIfExists(fichero);
        }
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}
