package com.tresenraya.interfaz;

import java.awt.Point;
import java.awt.Robot;
import java.awt.Window;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.time.LocalDateTime;
import java.util.List;

import javax.swing.SwingUtilities;

import com.tresenraya.modelo.Dificultad;
import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;
import com.tresenraya.persistencia.HistorialConsola;
import com.tresenraya.persistencia.PartidaGuardada;
import com.tresenraya.persistencia.ResultadoPartida;

public class TecladoTableroTest {
    public static void main(String[] args) throws Exception {
        try {
            Robot robot = new Robot();
            robot.setAutoWaitForIdle(true);
            robot.setAutoDelay(75);
            comprobarLimitesYMovimiento(robot);
            comprobarVictoriaConTeclado(robot);
            comprobarEmpateConTeclado(robot);
            comprobarRespuestaDeIa(robot);
            comprobarPartidaCargadaSoloLectura();
            System.out.println("Pruebas reales de teclado del tablero superadas");
        } finally {
            SwingUtilities.invokeAndWait(() -> {
                for (Window ventana : Window.getWindows()) {
                    ventana.dispose();
                }
            });
        }
    }

    private static void comprobarLimitesYMovimiento(Robot robot) throws Exception {
        VentanaJuego ventana = crearVentanaHumana(robot);
        pulsar(robot, KeyEvent.VK_LEFT);
        pulsar(robot, KeyEvent.VK_UP);
        comprobar(ventana.getPanelTablero().getFilaSeleccionada() == 0
                && ventana.getPanelTablero().getColumnaSeleccionada() == 0,
                "La selección salió por el borde superior izquierdo");
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_DOWN);
        pulsar(robot, KeyEvent.VK_LEFT);
        pulsar(robot, KeyEvent.VK_UP);
        comprobar(ventana.getPanelTablero().getFilaSeleccionada() == 0
                && ventana.getPanelTablero().getColumnaSeleccionada() == 0,
                "Las flechas no recorrieron la cuadrícula correctamente");
        pulsar(robot, KeyEvent.VK_SPACE);
        comprobar(ventana.getPartida().numeroMovimientos() == 1
                && ventana.getPanelTablero().getBoton(0, 0).getText().equals("X"),
                "Espacio no realizó el movimiento seleccionado");
        pulsar(robot, KeyEvent.VK_SPACE);
        comprobar(ventana.getPartida().numeroMovimientos() == 1,
                "Una casilla ocupada fue sobrescrita con Espacio");
        cerrar(ventana);
    }

    private static void comprobarVictoriaConTeclado(Robot robot) throws Exception {
        VentanaJuego ventana = crearVentanaHumana(robot);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_DOWN);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_UP);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_DOWN);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_UP);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_SPACE);
        comprobar(ventana.getPartida().haTerminado() && ventana.getPartida().ganador().getSimbolo() == 'X',
                "La partida no terminó con victoria de X usando teclado");
        cerrar(ventana);
    }

    private static void comprobarRespuestaDeIa(Robot robot) throws Exception {
        final VentanaJuego[] resultado = new VentanaJuego[1];
        SwingUtilities.invokeAndWait(() -> {
            resultado[0] = new VentanaJuego(Dificultad.FACIL, new HistorialConsola());
            resultado[0].setVisible(true);
        });
        VentanaJuego ventana = resultado[0];
        enfocar(ventana, robot);
        pulsar(robot, KeyEvent.VK_SPACE);
        comprobar(ventana.getPartida().numeroMovimientos() == 2,
                "La IA no respondió al movimiento realizado con Espacio");
        cerrar(ventana);
    }

    private static void comprobarEmpateConTeclado(Robot robot) throws Exception {
        VentanaJuego ventana = crearVentanaHumana(robot);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_DOWN);
        pulsar(robot, KeyEvent.VK_LEFT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_LEFT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_DOWN);
        pulsar(robot, KeyEvent.VK_LEFT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_LEFT);
        pulsar(robot, KeyEvent.VK_SPACE);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_RIGHT);
        pulsar(robot, KeyEvent.VK_SPACE);
        comprobar(ventana.getPartida().hayEmpate(), "La partida no terminó en empate con teclado");
        cerrar(ventana);
    }

    private static void comprobarPartidaCargadaSoloLectura() throws Exception {
        Jugador jugadorX = new Jugador("X", 'X', true);
        Jugador jugadorO = new Jugador("O", 'O', true);
        PartidaGuardada guardada = new PartidaGuardada(
                new ResultadoPartida(jugadorX, jugadorO, jugadorX, 1, LocalDateTime.now()),
                List.of(new Movimiento(0, 0, jugadorX)));
        final VentanaPartidaCargada[] resultado = new VentanaPartidaCargada[1];
        SwingUtilities.invokeAndWait(() -> {
            resultado[0] = new VentanaPartidaCargada(guardada);
            resultado[0].setVisible(true);
        });
        comprobar(!resultado[0].getPanelTablero().getBoton(0, 0).isEnabled(),
                "La partida cargada permite modificar el tablero");
        cerrar(resultado[0]);
    }

    private static VentanaJuego crearVentanaHumana(Robot robot) throws Exception {
        final VentanaJuego[] resultado = new VentanaJuego[1];
        SwingUtilities.invokeAndWait(() -> {
            resultado[0] = new VentanaJuego(new Partida(
                    new Jugador("X", 'X', true), new Jugador("O", 'O', true)), new HistorialConsola());
            resultado[0].setVisible(true);
        });
        enfocar(resultado[0], robot);
        return resultado[0];
    }

    private static void enfocar(VentanaJuego ventana, Robot robot) throws Exception {
        javax.swing.JButton casillaInicial = ventana.getPanelTablero().getBoton(0, 0);
        Point origen = ventana.getLocationOnScreen();
        robot.mouseMove(origen.x + 60, origen.y + 10);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();
        SwingUtilities.invokeAndWait(() -> {
            ventana.toFront();
            ventana.requestFocus();
            casillaInicial.requestFocusInWindow();
        });
        long limite = System.nanoTime() + 3_000_000_000L;
        while ((java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner() != casillaInicial
                || !ventana.isActive()) && System.nanoTime() < limite) {
            if (!ventana.isActive()) {
                SwingUtilities.invokeAndWait(() -> {
                    ventana.toFront();
                    ventana.requestFocus();
                });
            } else {
                SwingUtilities.invokeAndWait(casillaInicial::requestFocusInWindow);
            }
            robot.delay(50);
        }
        comprobar(java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner() == casillaInicial
                && ventana.isActive(), "No se pudo dar foco al tablero para la prueba de teclado");
    }

    private static void pulsar(Robot robot, int tecla) {
        robot.keyPress(tecla);
        robot.keyRelease(tecla);
        robot.waitForIdle();
    }

    private static void cerrar(java.awt.Window ventana) throws Exception {
        SwingUtilities.invokeAndWait(ventana::dispose);
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}
