package com.tresenraya.interfaz;

import java.awt.Component;
import java.awt.Container;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;

import com.tresenraya.configuracion.Configuracion;
import com.tresenraya.interfaz.componentes.PanelTablero;
import com.tresenraya.modelo.Partida;
import com.tresenraya.modelo.Jugador;
import com.tresenraya.persistencia.HistorialConsola;

public class AccesibilidadTest {
    public static void main(String[] args) {
        comprobarInicio();
        comprobarTablero();
        comprobarDificultad();
        comprobarConfiguracion();
        comprobarJuego();
        comprobarHistorial();
        System.out.println("Pruebas de accesibilidad superadas");
    }

    private static void comprobarInicio() {
        VentanaInicio ventana = new VentanaInicio();
        List<JButton> botones = botonesDe(ventana.getContentPane());
        comprobar(textos(botones).equals(List.of("Nueva partida", "Cargar partida", "Configuración", "Salir")),
                "El orden de Tab de Inicio no es lógico");
        comprobar(botones.get(0).getMnemonic() == 'N' && botones.get(1).getMnemonic() == 'A'
                && botones.get(2).getMnemonic() == 'C' && botones.get(3).getMnemonic() == 'S',
                "Faltan mnemonics apropiados en Inicio");
        comprobar(ventana.getWidth() >= 530 && ventana.getHeight() >= 480,
                "La ventana inicial sigue siendo demasiado pequeña");
        for (JButton boton : botones) {
            comprobar(boton.getPreferredSize().width >= 300 && boton.getPreferredSize().height >= 45,
                    "Los botones de Inicio no tienen un tamaño cómodo");
            comprobar(boton.getFont().getSize2D() >= 16f, "El texto de Inicio es demasiado pequeño");
        }
        comprobar(componentesDeTipo(ventana.getContentPane(), JLabel.class).stream()
                .map(JLabel.class::cast)
                .anyMatch(etiqueta -> etiqueta.getText().equals("Tres en Raya")
                        && etiqueta.getFont().isBold() && etiqueta.getFont().getSize2D() >= 30f),
                "El título de Inicio no destaca");
        comprobar(componentesDeTipo(ventana.getContentPane(), JLabel.class).stream()
                .map(JLabel.class::cast)
                .anyMatch(etiqueta -> etiqueta.getText().contains("Alt + A: Cargar partida")),
                "Los atajos de teclado no se muestran de forma legible");
        comprobar(ventana.getFocusTraversalPolicy() != null, "Inicio no tiene política de foco");
        VentanaModoJuego selector = new VentanaModoJuego(modo -> { }, () -> { });
        List<JButton> opcionesModo = botonesDe(selector.getContentPane());
        comprobar(textos(opcionesModo).equals(List.of(
                "Jugador vs Jugador", "Jugador vs IA", "Volver")),
                "El orden de Tab del selector de modo no es lógico");
        comprobar(opcionesModo.get(0).getMnemonic() == 'J' && opcionesModo.get(1).getMnemonic() == 'I'
                && opcionesModo.get(2).getMnemonic() == 'V',
                "Faltan mnemonics en el selector de modo");
        cerrar(selector);
        cerrar(ventana);
    }

    private static void comprobarTablero() {
        PanelTablero tablero = new PanelTablero();
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                JButton boton = tablero.getBoton(fila, columna);
                comprobar(boton.isFocusable() && boton.isFocusPainted(), "Casilla sin foco visible");
                comprobar(boton.getActionCommand().equals(fila + "," + columna),
                        "Casilla sin coordenadas de acción");
            }
        }
        comprobar(tablero.getFocusTraversalPolicy() != null, "El tablero no define orden de foco");
    }

    private static void comprobarDificultad() {
        VentanaDificultad ventana = new VentanaDificultad();
        List<JButton> botones = botonesDe(ventana.getContentPane());
        comprobar(botones.get(0).getMnemonic() == 'F' && botones.get(1).getMnemonic() == 'M'
                && botones.get(2).getMnemonic() == 'D', "Faltan mnemonics de dificultad");
        comprobar(botones.size() == 4 && botones.get(3).getMnemonic() == 'V',
                "Falta el control Volver de dificultad");
        for (JButton boton : botones) {
            comprobar(boton.isFocusable() && boton.isFocusPainted(), "Dificultad sin foco visible");
        }
        cerrar(ventana);
    }

    private static void comprobarConfiguracion() {
        VentanaConfiguracion ventana = new VentanaConfiguracion(new Configuracion());
        comprobar(ventana.getCampoJugadorX().isFocusable(), "Campo X sin foco");
        comprobar(ventana.getCampoJugadorO().isFocusable(), "Campo O sin foco");
        comprobar(componentesDeTipo(ventana.getContentPane(), javax.swing.JComboBox.class).isEmpty(),
                "Configuración no debe mostrar selectores");
        comprobar(componentesDeTipo(ventana.getContentPane(), JLabel.class).stream()
                .map(componente -> ((JLabel) componente).getText())
                .noneMatch(texto -> texto.toLowerCase().contains("dificultad")),
                "Configuración no debe mostrar la etiqueta de dificultad");
        List<JButton> botones = botonesDe(ventana.getContentPane());
        JButton guardar = botonConTexto(botones, "Guardar");
        JButton volver = botonConTexto(botones, "Volver");
        comprobar(guardar != null && volver != null && guardar.getMnemonic() == 'G'
            && volver.getMnemonic() == 'V',
                "Faltan mnemonics de configuración");
        cerrar(ventana);
    }

    private static void comprobarJuego() {
        Partida partida = new Partida(new Jugador("X", 'X', true), new Jugador("O", 'O', true));
        VentanaJuego ventana = new VentanaJuego(partida, new HistorialConsola());
        List<JButton> botones = botonesDe(ventana.getContentPane());
        comprobar(ventana.getPanelTablero().getBoton(0, 0).isFocusable(), "Casillas del juego inaccesibles");
        comprobar(botones.get(botones.size() - 2).getMnemonic() == 'N'
                && botones.get(botones.size() - 1).getMnemonic() == 'V',
                "Faltan mnemonics de Juego");
        cerrar(ventana);
    }

    private static void comprobarHistorial() {
        VentanaHistorial ventana = new VentanaHistorial(new HistorialConsola());
        comprobar(ventana.getListaResultados().isFocusable(), "Lista de historial sin foco");
        comprobar(!ventana.getBotonVerPartida().isEnabled(), "Ver partida debe empezar deshabilitado");
        comprobar(ventana.getBotonVerPartida().getMnemonic() == 'V', "Falta mnemonic de Ver partida");
        cerrar(ventana);
    }

    private static List<JButton> botonesDe(Container contenedor) {
        List<JButton> resultado = new ArrayList<>();
        for (Component componente : contenedor.getComponents()) {
            if (componente instanceof JButton boton) {
                resultado.add(boton);
            }
            if (componente instanceof Container hijo) {
                resultado.addAll(botonesDe(hijo));
            }
        }
        return resultado;
    }

    private static List<Component> componentesDeTipo(Container contenedor, Class<?> tipo) {
        List<Component> resultado = new ArrayList<>();
        for (Component componente : contenedor.getComponents()) {
            if (tipo.isInstance(componente)) {
                resultado.add(componente);
            }
            if (componente instanceof Container hijo) {
                resultado.addAll(componentesDeTipo(hijo, tipo));
            }
        }
        return resultado;
    }

    private static List<String> textos(List<JButton> botones) {
        return botones.stream().map(JButton::getText).toList();
    }

    private static JButton botonConTexto(List<JButton> botones, String texto) {
        return botones.stream().filter(boton -> texto.equals(boton.getText())).findFirst().orElse(null);
    }

    private static void cerrar(java.awt.Window ventana) {
        ventana.dispose();
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}
