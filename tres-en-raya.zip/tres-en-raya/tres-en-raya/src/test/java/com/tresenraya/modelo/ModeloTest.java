package com.tresenraya.modelo;

class ModeloTest {
    public static void main(String[] args) {
        jugadorYMovimientoConservanSusDatos();
        partidaAlternaTurnosYRegistraMovimientos();
        partidaDetectaVictoriaPorFila();
        partidaDetectaVictoriaPorColumna();
        partidaDetectaVictoriaPorDiagonal();
        partidaDetectaLasOchoCombinacionesGanadoras();
        partidaDetectaVictoriaDeO();
        partidaDetectaEmpateSinGanador();
        partidaRechazaJugadasInvalidas();
        partidaReiniciaSuEstado();
        partidaRegistraCadaMovimiento();
        dificultadesDisponibles();
        System.out.println("Pruebas del modelo superadas");
    }

    private static void jugadorYMovimientoConservanSusDatos() {
        Jugador jugador = new Jugador("Ana", 'x', true);
        Movimiento movimiento = new Movimiento(1, 2, jugador);

        assertEquals("Ana", jugador.getNombre());
        assertEquals('X', jugador.getSimbolo());
        assertTrue(jugador.esHumano());
        assertFalse(jugador.esIa());
        assertEquals(1, movimiento.getFila());
        assertEquals(2, movimiento.getColumna());
        assertEquals(jugador, movimiento.getJugador());
    }

    private static void partidaAlternaTurnosYRegistraMovimientos() {
        Jugador jugadorX = jugador("X", 'X');
        Jugador jugadorO = jugador("O", 'O');
        Partida partida = new Partida(jugadorX, jugadorO);

        assertEquals(jugadorX, partida.turnoActual());
        partida.marcar(0, 0);
        partida.marcar(1, 1);

        assertEquals(jugadorX, partida.turnoActual());
        assertEquals(2, partida.numeroMovimientos());
        assertFalse(partida.estaLibre(0, 0));
    }

    private static void partidaDetectaLasOchoCombinacionesGanadoras() {
        int[][][] lineas = {
            {{0, 0}, {0, 1}, {0, 2}},
            {{1, 0}, {1, 1}, {1, 2}},
            {{2, 0}, {2, 1}, {2, 2}},
            {{0, 0}, {1, 0}, {2, 0}},
            {{0, 1}, {1, 1}, {2, 1}},
            {{0, 2}, {1, 2}, {2, 2}},
            {{0, 0}, {1, 1}, {2, 2}},
            {{0, 2}, {1, 1}, {2, 0}}
        };

        for (int[][] linea : lineas) {
            Jugador jugadorX = jugador("X", 'X');
            Jugador jugadorO = jugador("O", 'O');
            Partida partida = new Partida(jugadorX, jugadorO);
            partida.marcar(linea[0][0], linea[0][1]);
            marcarCasillaFueraDeLinea(partida, linea);
            partida.marcar(linea[1][0], linea[1][1]);
            marcarCasillaFueraDeLinea(partida, linea);
            partida.marcar(linea[2][0], linea[2][1]);

            assertTrue(partida.haTerminado());
            assertEquals(jugadorX, partida.ganador());
        }
    }

    private static void partidaDetectaVictoriaPorFila() {
        Partida partida = nuevaPartida();
        partida.marcar(0, 0);
        partida.marcar(1, 0);
        partida.marcar(0, 1);
        partida.marcar(1, 1);
        partida.marcar(0, 2);

        assertEquals("X", partida.ganador().getNombre());
        assertTrue(partida.haTerminado());
    }

    private static void partidaDetectaVictoriaPorColumna() {
        Partida partida = nuevaPartida();
        partida.marcar(0, 0);
        partida.marcar(0, 1);
        partida.marcar(1, 0);
        partida.marcar(1, 1);
        partida.marcar(2, 0);

        assertEquals("X", partida.ganador().getNombre());
        assertTrue(partida.haTerminado());
    }

    private static void partidaDetectaVictoriaPorDiagonal() {
        Partida partida = nuevaPartida();
        partida.marcar(0, 0);
        partida.marcar(0, 1);
        partida.marcar(1, 1);
        partida.marcar(0, 2);
        partida.marcar(2, 2);

        assertEquals("X", partida.ganador().getNombre());
        assertTrue(partida.haTerminado());
    }

    private static void partidaDetectaVictoriaDeO() {
        Partida partida = nuevaPartida();
        partida.marcar(0, 0);
        partida.marcar(1, 0);
        partida.marcar(2, 2);
        partida.marcar(1, 1);
        partida.marcar(0, 1);
        partida.marcar(1, 2);

        assertEquals("O", partida.ganador().getNombre());
        assertEquals('O', partida.tablero()[1][2]);
    }

    private static void partidaDetectaEmpateSinGanador() {
        Partida partida = new Partida(jugador("X", 'X'), jugador("O", 'O'));
        int[][] jugadas = {
            {0, 0}, {0, 1}, {0, 2},
            {1, 1}, {1, 0}, {1, 2},
            {2, 1}, {2, 0}, {2, 2}
        };

        for (int[] jugada : jugadas) {
            partida.marcar(jugada[0], jugada[1]);
        }

        assertTrue(partida.haTerminado());
        assertTrue(partida.hayEmpate());
        assertEquals(9, partida.numeroMovimientos());
        assertEquals(null, partida.ganador());
    }

    private static void partidaRechazaJugadasInvalidas() {
        Partida partida = new Partida(jugador("X", 'X'), jugador("O", 'O'));

        esperarIllegalArgumentException(() -> partida.marcar(3, 0));
        partida.marcar(0, 0);
        esperarIllegalArgumentException(() -> partida.marcar(0, 0));
    }

    private static void partidaReiniciaSuEstado() {
        Partida partida = nuevaPartida();
        partida.marcar(0, 0);
        partida.marcar(1, 0);
        partida.marcar(0, 1);
        partida.marcar(1, 1);
        partida.marcar(0, 2);

        partida.reiniciar();

        assertFalse(partida.haTerminado());
        assertEquals(null, partida.ganador());
        assertEquals(0, partida.numeroMovimientos());
        assertEquals("X", partida.turnoActual().getNombre());
        assertTrue(partida.estaLibre(0, 0));
    }

    private static void partidaRegistraCadaMovimiento() {
        Partida partida = nuevaPartida();
        Movimiento movimiento = partida.marcar(2, 1);

        assertEquals(1, partida.numeroMovimientos());
        assertEquals(1, partida.movimientos().size());
        assertEquals(movimiento, partida.movimientos().get(0));
        assertEquals(2, movimiento.getFila());
        assertEquals(1, movimiento.getColumna());
        assertEquals("X", movimiento.getJugador().getNombre());
    }

    private static void dificultadesDisponibles() {
        assertEquals(3, Dificultad.values().length);
        assertEquals(Dificultad.FACIL, Dificultad.valueOf("FACIL"));
        assertEquals(Dificultad.MEDIA, Dificultad.valueOf("MEDIA"));
        assertEquals(Dificultad.DIFICIL, Dificultad.valueOf("DIFICIL"));
    }

    private static Partida nuevaPartida() {
        return new Partida(jugador("X", 'X'), jugador("O", 'O'));
    }

    private static Jugador jugador(String nombre, char simbolo) {
        return new Jugador(nombre, simbolo, true);
    }

    private static void marcarCasillaFueraDeLinea(Partida partida, int[][] linea) {
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                if (!esParteDeLinea(fila, columna, linea) && partida.estaLibre(fila, columna)) {
                    partida.marcar(fila, columna);
                    return;
                }
            }
        }
    }

    private static boolean esParteDeLinea(int fila, int columna, int[][] linea) {
        for (int[] posicion : linea) {
            if (posicion[0] == fila && posicion[1] == columna) {
                return true;
            }
        }
        return false;
    }

    private static void esperarIllegalArgumentException(Runnable accion) {
        try {
            accion.run();
            throw new AssertionError("Se esperaba una IllegalArgumentException");
        } catch (IllegalArgumentException esperado) {
        }
    }

    private static void assertEquals(Object esperado, Object actual) {
        if (esperado == null ? actual != null : !esperado.equals(actual)) {
            throw new AssertionError("Esperado: " + esperado + ", actual: " + actual);
        }
    }

    private static void assertTrue(boolean condicion) {
        if (!condicion) {
            throw new AssertionError("Se esperaba una condición verdadera");
        }
    }

    private static void assertFalse(boolean condicion) {
        if (condicion) {
            throw new AssertionError("Se esperaba una condición falsa");
        }
    }
}