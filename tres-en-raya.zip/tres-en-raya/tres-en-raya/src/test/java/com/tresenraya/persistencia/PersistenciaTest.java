package com.tresenraya.persistencia;

import java.time.LocalDateTime;

import com.tresenraya.modelo.Jugador;

public class PersistenciaTest {
    public static void main(String[] args) {
        Jugador jugadorX = new Jugador("Ana", 'X', true);
        Jugador jugadorO = new Jugador("Luis", 'O', true);
        LocalDateTime fecha = LocalDateTime.of(2026, 9, 25, 10, 0);
        ResultadoPartida resultado = new ResultadoPartida(jugadorX, jugadorO, jugadorX, 5, fecha);
        HistorialConsola historial = new HistorialConsola();

        historial.guardar(resultado);

        comprobar(historial.getResultados().size() == 1, "El resultado no se guardó");
        ResultadoPartida guardado = historial.getResultados().get(0);
        comprobar(guardado.getJugadorX() == jugadorX, "No se guardó jugadorX");
        comprobar(guardado.getJugadorO() == jugadorO, "No se guardó jugadorO");
        comprobar(guardado.getGanador() == jugadorX, "No se guardó el ganador");
        comprobar(guardado.getNumeroMovimientos() == 5, "No se guardó el número de movimientos");
        comprobar(guardado.getFecha().equals(fecha), "No se guardó la fecha");
        System.out.println("Prueba de persistencia superada");
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}