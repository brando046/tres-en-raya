package com.tresenraya.interfaz;

import java.awt.Component;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import com.tresenraya.modelo.Dificultad;
import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.ModoJuego;
import com.tresenraya.modelo.Partida;
import com.tresenraya.persistencia.HistorialFichero;

public class VentanaJuegoTest {
    public static void main(String[] args) throws Exception {
        comprobarFlujoNuevaPartida();
        comprobarModoJugadorVsJugador();
        comprobarConfiguracionVisibleYAplicada();
        comprobarNombresEnCadaDificultadEHistorial();
        comprobarCargarPartida();
        comprobarPartidaContraIa();
        comprobarVictoriaYBloqueo();
        comprobarEmpate();
        comprobarReinicio();
        comprobarSalir();
        System.out.println("Pruebas completas del juego superadas");
    }

    private static void comprobarFlujoNuevaPartida() throws Exception {
        VentanaInicio inicio = crearVentanaInicio();
        pulsarBoton(inicio, "Nueva partida");

        comprobar(inicio.getVentanaModoJuego() != null && inicio.getVentanaModoJuego().isVisible(),
                "Nueva partida no mostró VentanaModoJuego");
        pulsarBoton(inicio.getVentanaModoJuego(), "Jugador vs IA");
        comprobar(inicio.getVentanaDificultad() != null && inicio.getVentanaDificultad().isVisible(),
            "El modo Jugador vs IA no mostró VentanaDificultad");
        pulsarBoton(inicio.getVentanaDificultad(), "Fácil");
        comprobar(inicio.getVentanaJuego() != null, "La dificultad no creó VentanaJuego");
        comprobar(inicio.getVentanaJuego().isVisible(), "VentanaJuego no se mostró");
        comprobar(inicio.getVentanaJuego().getModoJuego() == ModoJuego.JUGADOR_VS_IA,
                "VentanaJuego no recibió el modo Jugador vs IA");
        comprobar(inicio.getVentanaJuego().getPanelTablero().getComponentCount() == 9,
                "VentanaJuego no mostró el tablero 3x3");

        cerrar(inicio.getVentanaJuego());
        SwingUtilities.invokeAndWait(inicio::dispose);
    }

    private static void comprobarModoJugadorVsJugador() throws Exception {
        VentanaInicio inicio = crearVentanaInicio();
        inicio.getConfiguracion().setJugadorX("Brandon");
        inicio.getConfiguracion().setJugadorO("Luisa");
        pulsarBoton(inicio, "Nueva partida");
        VentanaModoJuego selector = inicio.getVentanaModoJuego();
        comprobar(selector != null && selector.isVisible(), "No se abrió la selección de modo");
        pulsarBoton(selector, "Jugador vs Jugador");

        VentanaJuego juego = inicio.getVentanaJuego();
        comprobar(juego != null && juego.isVisible(), "No se inició la partida local");
        comprobar(juego.getModoJuego() == ModoJuego.JUGADOR_VS_JUGADOR,
                "La partida no conserva el modo Jugador vs Jugador");
        comprobar(juego.getDificultad() == null && juego.getInteligenciaArtificial() == null,
                "El modo Jugador vs Jugador creó una dificultad o una IA");
        comprobar(juego.getPartida().jugadorX().esHumano() && juego.getPartida().jugadorO().esHumano(),
                "Ambos participantes deben ser humanos");
        comprobar(juego.getPartida().jugadorX().getNombre().equals("Brandon")
                && juego.getPartida().jugadorO().getNombre().equals("Luisa"),
                "El modo local no conservó los nombres configurados");
        comprobar(juego.getPanelInformacion().getEtiquetaModo().getText().equals("Modo: JUGADOR VS JUGADOR")
                && !juego.getPanelInformacion().getEtiquetaModo().getText().contains("Dificultad"),
                "La interfaz local muestra información de IA");
        comprobar(juego.getPanelInformacion().getEtiquetaJugadores().getText()
                .equals("Jugador X: Brandon | Jugador O: Luisa"),
                "La interfaz local no muestra los nombres de los jugadores");
        pulsarCasilla(juego, 0, 0);
        comprobar(juego.getPartida().numeroMovimientos() == 1
                && juego.getPartida().turnoActual().getSimbolo() == 'O',
                "El turno no pasó de X a O en el modo local");
        pulsarCasilla(juego, 1, 1);
        comprobar(juego.getPartida().numeroMovimientos() == 2
                && juego.getPartida().turnoActual().getSimbolo() == 'X',
                "El jugador O no pudo mover o el turno no volvió a X");

        int[][] victoriaX = {{0, 1}, {2, 0}, {0, 2}};
        for (int[] casilla : victoriaX) {
            pulsarCasilla(juego, casilla[0], casilla[1]);
        }
        comprobar(juego.getPartida().ganador() != null
                && juego.getPartida().ganador().getSimbolo() == 'X',
                "La partida local no detectó la victoria de X");
        comprobar(juego.getResultadoRegistrado() != null
                && juego.getResultadoRegistrado().getJugadorX().getNombre().equals("Brandon")
                && juego.getResultadoRegistrado().getJugadorO().getNombre().equals("Luisa"),
                "El resultado local no guardó los nombres correctos");
        int movimientosFinales = juego.getPartida().numeroMovimientos();
        pulsarCasilla(juego, 2, 2);
        comprobar(juego.getPartida().numeroMovimientos() == movimientosFinales,
                "El modo local permitió mover después de terminar");

        cerrar(juego);
        SwingUtilities.invokeAndWait(inicio::dispose);
    }

    private static void comprobarConfiguracionVisibleYAplicada() throws Exception {
        VentanaInicio inicio = crearVentanaInicio();
        pulsarBoton(inicio, "Configuración");
        VentanaConfiguracion configuracion = inicio.getVentanaConfiguracion();
        comprobar(configuracion != null && configuracion.isVisible(), "Configuración no se abrió");
        pulsarBoton(inicio, "Configuración");
        comprobar(inicio.getVentanaConfiguracion() == configuracion,
                "Un segundo clic creó una ventana de configuración duplicada");
        comprobar(componentesDeTipo(configuracion.getContentPane(), JComboBox.class).isEmpty(),
                "Configuración muestra un selector que no corresponde a los nombres");
        comprobar(!hayEtiquetaDificultad(configuracion.getContentPane()),
                "Configuración muestra una etiqueta de dificultad");
        SwingUtilities.invokeAndWait(() -> {
            configuracion.getCampoJugadorX().setText("Brandon");
            configuracion.getCampoJugadorO().setText("IA");
        });
        pulsarBoton(configuracion, "Guardar");
        comprobar(inicio.getConfiguracion().getJugadorX().equals("Brandon"), "No se guardó el nombre de X");
        comprobar(inicio.getConfiguracion().getJugadorO().equals("IA"),
            "No se guardó el nombre de O");
        pulsarBoton(inicio, "Nueva partida");
        pulsarBoton(inicio.getVentanaModoJuego(), "Jugador vs IA");
        comprobar(inicio.getVentanaDificultad() != null && inicio.getVentanaDificultad().isVisible(),
            "Nueva partida no mostró VentanaDificultad");
        pulsarBoton(inicio.getVentanaDificultad(), "Difícil");
        comprobar(inicio.getVentanaJuego().getDificultad() == Dificultad.DIFICIL,
            "La partida no utilizó la dificultad seleccionada");
        comprobar(inicio.getVentanaJuego().getPartida().jugadorX().getNombre().equals("Brandon"),
            "La partida no utilizó el nombre de X");
        comprobar(inicio.getVentanaJuego().getPartida().jugadorO().getNombre().equals("IA"),
            "La partida no utilizó el nombre de O");
        cerrar(inicio.getVentanaJuego());
        SwingUtilities.invokeAndWait(inicio::dispose);
    }

    private static void comprobarNombresEnCadaDificultadEHistorial() throws Exception {
        Path fichero = Files.createTempFile("tres-en-raya-flujo", ".txt");
        Files.deleteIfExists(fichero);
        VentanaInicio inicio = crearVentanaInicio(new HistorialFichero(fichero));
        try {
            pulsarBoton(inicio, "Configuración");
            VentanaConfiguracion configuracion = inicio.getVentanaConfiguracion();
            SwingUtilities.invokeAndWait(() -> {
                configuracion.getCampoJugadorX().setText("Brandon");
                configuracion.getCampoJugadorO().setText("IA");
            });
            pulsarBoton(configuracion, "Guardar");
            comprobar(inicio.isVisible(), "Guardar no volvió a Inicio");

            for (Dificultad dificultad : Dificultad.values()) {
                comprobar(inicio.isVisible(), "No se volvió a Inicio al cerrar la partida anterior");
                pulsarBoton(inicio, "Nueva partida");
                comprobar(inicio.getVentanaModoJuego() != null && inicio.getVentanaModoJuego().isVisible(),
                        "Nueva partida no mostró selector de modo");
                pulsarBoton(inicio.getVentanaModoJuego(), "Jugador vs IA");
                VentanaDificultad selector = inicio.getVentanaDificultad();
                comprobar(selector != null && selector.isVisible(),
                        "Nueva partida no abrió VentanaDificultad para " + dificultad);
                pulsarBoton(selector, textoDificultad(dificultad));

                VentanaJuego juego = inicio.getVentanaJuego();
                comprobar(juego.isVisible() && juego.getDificultad() == dificultad,
                        "VentanaJuego no recibió la dificultad " + dificultad);
                comprobar(juego.getModoJuego() == ModoJuego.JUGADOR_VS_IA,
                        "VentanaJuego no conservó el modo IA");
                comprobar(juego.getPanelInformacion().getEtiquetaModo().getText()
                        .contains("Dificultad: " + textoDificultad(dificultad)),
                        "La interfaz no muestra la dificultad seleccionada");
                comprobar(usaIaEsperada(juego, dificultad),
                        "La dificultad no seleccionó su implementación de IA: " + dificultad);
                comprobar(juego.getPartida().jugadorX().getNombre().equals("Brandon")
                        && juego.getPartida().jugadorO().getNombre().equals("IA"),
                        "Se perdieron los nombres configurados en " + dificultad);
                terminarPartida(juego);
                comprobar(juego.getResultadoRegistrado() != null,
                        "La partida no se registró en el historial para " + dificultad);
                comprobar(!inicio.getConfiguracion().getJugadorX().isBlank()
                        && inicio.getConfiguracion().getJugadorX().equals("Brandon")
                        && inicio.getConfiguracion().getJugadorO().equals("IA"),
                        "La configuración de nombres cambió después de " + dificultad);

                pulsarBoton(juego, "Volver al inicio");
                SwingUtilities.invokeAndWait(() -> {
                });
                comprobar(inicio.isVisible(), "Salir de la partida no devolvió a Inicio");
            }

            pulsarBoton(inicio, "Cargar partida");
            VentanaHistorial historial = inicio.getVentanaHistorial();
            comprobar(historial != null && historial.isVisible(),
                    "Cargar partida no abrió el historial desde el menú");
            comprobar(historial.getListaResultados().getModel().getSize() == 3,
                    "El historial no conservó las tres partidas");
            pulsarBoton(inicio, "Cargar partida");
            comprobar(inicio.getVentanaHistorial() == historial,
                    "Un segundo clic creó una ventana de historial duplicada");
            comprobar(historial.getBotonVerPartida().isEnabled(),
                    "No se pudo seleccionar una partida guardada");
            SwingUtilities.invokeAndWait(historial.getBotonVerPartida()::doClick);
            comprobar(historial.getVentanaPartidaCargada() != null
                    && historial.getVentanaPartidaCargada().isVisible(),
                    "El historial no abrió VentanaPartidaCargada");
            for (int fila = 0; fila < 3; fila++) {
                for (int columna = 0; columna < 3; columna++) {
                    comprobar(!historial.getVentanaPartidaCargada().getPanelTablero()
                            .getBoton(fila, columna).isEnabled(),
                            "El tablero cargado no está en modo solo lectura");
                }
            }
            SwingUtilities.invokeAndWait(historial.getVentanaPartidaCargada()::dispose);
            SwingUtilities.invokeAndWait(historial::dispose);
        } finally {
            SwingUtilities.invokeAndWait(inicio::dispose);
            Files.deleteIfExists(fichero);
        }
    }

    private static void terminarPartida(VentanaJuego juego) throws Exception {
        while (!juego.getPartida().haTerminado()) {
            char[][] tablero = juego.getPartida().tablero();
            int filaLibre = -1;
            int columnaLibre = -1;
            for (int fila = 0; fila < 3 && filaLibre < 0; fila++) {
                for (int columna = 0; columna < 3; columna++) {
                    if (tablero[fila][columna] == '\0') {
                        filaLibre = fila;
                        columnaLibre = columna;
                        break;
                    }
                }
            }
            comprobar(filaLibre >= 0, "La partida no terminó con el tablero lleno");
            pulsarCasilla(juego, filaLibre, columnaLibre);
        }
    }

    private static String textoDificultad(Dificultad dificultad) {
        return switch (dificultad) {
            case FACIL -> "Fácil";
            case MEDIA -> "Media";
            case DIFICIL -> "Difícil";
        };
    }

    private static boolean usaIaEsperada(VentanaJuego juego, Dificultad dificultad) {
        return switch (dificultad) {
            case FACIL -> juego.getInteligenciaArtificial() instanceof com.tresenraya.ia.IaFacil;
            case MEDIA -> juego.getInteligenciaArtificial() instanceof com.tresenraya.ia.IaMedia;
            case DIFICIL -> juego.getInteligenciaArtificial() instanceof com.tresenraya.ia.IaDificil;
        };
    }

    private static void comprobarPartidaContraIa() throws Exception {
        for (Dificultad dificultad : Dificultad.values()) {
            VentanaJuego ventana = crearVentana(dificultad);
            comprobar(ventana.getDificultad() == dificultad, "No se conservó la dificultad seleccionada");
            comprobar(ventana.getPartida().numeroMovimientos() == 0, "El tablero inicial no está vacío");

            pulsarCasilla(ventana, 0, 0);

            comprobar(ventana.getPartida().numeroMovimientos() == 2,
                    "La máquina no respondió automáticamente en " + dificultad);
            comprobar(ventana.getPartida().turnoActual().getSimbolo() == 'X',
                    "No volvió el turno al jugador humano en " + dificultad);
            comprobar(ventana.getPartida().tablero()[0][0] == 'X', "La jugada humana no mostró X");
            comprobar(haySimboloO(ventana.getPartida().tablero()), "La máquina no colocó O");

            pulsarBoton(ventana, "Nueva partida");
            comprobar(ventana.getDificultad() == dificultad, "El reinicio perdió la dificultad");
            comprobar(ventana.getPartida().numeroMovimientos() == 0, "El reinicio no limpió la partida contra IA");
            comprobar(ventana.getPartida().turnoActual().getSimbolo() == 'X', "El reinicio no devolvió X");
            cerrar(ventana);
        }
    }

    private static void comprobarCargarPartida() throws Exception {
        VentanaInicio inicio = crearVentanaInicio();
        pulsarBoton(inicio, "Cargar partida");
        comprobar(inicio.getVentanaHistorial() != null && inicio.getVentanaHistorial().isVisible(),
                "Cargar partida no abrió VentanaHistorial");
        SwingUtilities.invokeAndWait(inicio.getVentanaHistorial()::dispose);
        SwingUtilities.invokeAndWait(inicio::dispose);
    }

    private static void comprobarVictoriaYBloqueo() throws Exception {
        Jugador jugadorX = new Jugador("Ana", 'X', true);
        Jugador jugadorO = new Jugador("Luis", 'O', true);
        Partida partida = new Partida(jugadorX, jugadorO);
        VentanaJuego ventana = crearVentana(partida);

        pulsarCasilla(ventana, 0, 0);
        pulsarCasilla(ventana, 1, 0);
        pulsarCasilla(ventana, 0, 1);
        pulsarCasilla(ventana, 1, 1);
        pulsarCasilla(ventana, 0, 2);

        comprobar(partida.haTerminado(), "La partida no terminó");
        comprobar(partida.ganador() == jugadorX, "El modelo no identificó a X como ganador");
        comprobar(partida.numeroMovimientos() == 5, "El número de jugadas no es 5");
        comprobar("X".equals(ventana.getPanelTablero().getBoton(0, 0).getText()),
                "La vista no mostró la primera X");
        comprobar("X".equals(ventana.getPanelTablero().getBoton(0, 2).getText()),
                "La vista no mostró la última X");
        comprobar("Resultado: Ganador: X".equals(etiquetaResultado(ventana)),
                "La vista no mostró el resultado");
        comprobar(ventana.getResultadoRegistrado() != null,
            "La partida terminada no generó ResultadoPartida");
        comprobar(ventana.getHistorial() instanceof com.tresenraya.persistencia.HistorialConsola
            && ((com.tresenraya.persistencia.HistorialConsola) ventana.getHistorial()).getResultados().size() == 1,
            "El resultado no se guardó en HistorialConsola");
        int movimientosAntes = partida.numeroMovimientos();
        pulsarCasilla(ventana, 2, 2);
        comprobar(partida.numeroMovimientos() == movimientosAntes, "Se permitió mover tras terminar");

        cerrar(ventana);
    }

    private static void comprobarEmpate() throws Exception {
        VentanaJuego ventana = crearVentana(new Partida(new Jugador("X", 'X', true), new Jugador("O", 'O', true)));
        int[][] jugadas = {
            {0, 0}, {0, 1}, {0, 2},
            {1, 1}, {1, 0}, {1, 2},
            {2, 1}, {2, 0}, {2, 2}
        };
        for (int[] jugada : jugadas) {
            pulsarCasilla(ventana, jugada[0], jugada[1]);
        }

        comprobar(ventana.getPartida().hayEmpate(), "La partida de empate no terminó correctamente");
        comprobar("Resultado: Empate".equals(etiquetaResultado(ventana)), "No se mostró Empate");
        cerrar(ventana);
    }

    private static void comprobarReinicio() throws Exception {
        VentanaJuego ventana = crearVentana(new Partida(new Jugador("X", 'X', true), new Jugador("O", 'O', true)));
        pulsarCasilla(ventana, 0, 0);
        pulsarBoton(ventana, "Nueva partida");

        comprobar(ventana.getPartida().numeroMovimientos() == 0, "El reinicio no puso el contador a cero");
        comprobar(ventana.getPartida().turnoActual().getSimbolo() == 'X', "El reinicio no devolvió el turno a X");
        comprobar("".equals(ventana.getPanelTablero().getBoton(0, 0).getText()),
            "El reinicio no limpió el tablero");
        cerrar(ventana);
    }

    private static void comprobarSalir() throws Exception {
        VentanaJuego ventana = crearVentana(new Partida(new Jugador("X", 'X', true), new Jugador("O", 'O', true)));
        pulsarBoton(ventana, "Volver al inicio");
        comprobar(!ventana.isDisplayable(), "El botón Volver al inicio no cerró VentanaJuego");
    }

    private static VentanaJuego crearVentana(Partida partida) throws Exception {
        final VentanaJuego[] resultado = new VentanaJuego[1];
        SwingUtilities.invokeAndWait(() -> resultado[0] = new VentanaJuego(partida));
        return resultado[0];
    }

    private static VentanaJuego crearVentana(Dificultad dificultad) throws Exception {
        final VentanaJuego[] resultado = new VentanaJuego[1];
        SwingUtilities.invokeAndWait(() -> resultado[0] = new VentanaJuego(dificultad));
        return resultado[0];
    }

    private static VentanaInicio crearVentanaInicio() throws Exception {
        final VentanaInicio[] resultado = new VentanaInicio[1];
        SwingUtilities.invokeAndWait(() -> {
            resultado[0] = new VentanaInicio();
            resultado[0].setVisible(true);
        });
        return resultado[0];
    }

    private static VentanaInicio crearVentanaInicio(HistorialFichero historial) throws Exception {
        final VentanaInicio[] resultado = new VentanaInicio[1];
        SwingUtilities.invokeAndWait(() -> {
            resultado[0] = new VentanaInicio(historial);
            resultado[0].setVisible(true);
        });
        return resultado[0];
    }

    private static void pulsarCasilla(VentanaJuego ventana, int fila, int columna) throws Exception {
        JButton boton = ventana.getPanelTablero().getBoton(fila, columna);
        SwingUtilities.invokeAndWait(boton::doClick);
    }

    private static void pulsarBoton(VentanaInicio ventana, String texto) throws Exception {
        JButton boton = buscarBoton(ventana.getContentPane(), texto);
        comprobar(boton != null, "No se encontró el botón " + texto);
        SwingUtilities.invokeAndWait(boton::doClick);
    }

    private static void pulsarBoton(VentanaModoJuego ventana, String texto) throws Exception {
        JButton boton = buscarBoton(ventana.getContentPane(), texto);
        comprobar(boton != null, "No se encontró el botón " + texto);
        SwingUtilities.invokeAndWait(boton::doClick);
    }

    private static void pulsarBoton(VentanaDificultad ventana, String texto) throws Exception {
        JButton boton = buscarBoton(ventana.getContentPane(), texto);
        comprobar(boton != null, "No se encontró el botón " + texto);
        SwingUtilities.invokeAndWait(boton::doClick);
    }

    private static void pulsarBoton(VentanaJuego ventana, String texto) throws Exception {
        JButton boton = buscarBoton(ventana.getContentPane(), texto);
        comprobar(boton != null, "No se encontró el botón " + texto);
        SwingUtilities.invokeAndWait(boton::doClick);
    }

    private static void pulsarBoton(VentanaConfiguracion ventana, String texto) throws Exception {
        JButton boton = buscarBoton(ventana.getContentPane(), texto);
        comprobar(boton != null, "No se encontró el botón " + texto);
        SwingUtilities.invokeAndWait(boton::doClick);
    }

    private static JButton buscarBoton(java.awt.Container contenedor, String texto) {
        for (Component componente : contenedor.getComponents()) {
            if (componente instanceof JButton boton && texto.equals(boton.getText())) {
                return boton;
            }
            if (componente instanceof java.awt.Container hijo) {
                JButton boton = buscarBoton(hijo, texto);
                if (boton != null) {
                    return boton;
                }
            }
        }
        return null;
    }

    private static java.util.List<Component> componentesDeTipo(java.awt.Container contenedor, Class<?> tipo) {
        java.util.List<Component> resultado = new java.util.ArrayList<>();
        for (Component componente : contenedor.getComponents()) {
            if (tipo.isInstance(componente)) {
                resultado.add(componente);
            }
            if (componente instanceof java.awt.Container hijo) {
                resultado.addAll(componentesDeTipo(hijo, tipo));
            }
        }
        return resultado;
    }

    private static boolean hayEtiquetaDificultad(java.awt.Container contenedor) {
        for (Component componente : contenedor.getComponents()) {
            if (componente instanceof JLabel etiqueta
                    && etiqueta.getText().toLowerCase().contains("dificultad")) {
                return true;
            }
            if (componente instanceof java.awt.Container hijo && hayEtiquetaDificultad(hijo)) {
                return true;
            }
        }
        return false;
    }

    private static void cerrar(VentanaJuego ventana) throws Exception {
        SwingUtilities.invokeAndWait(ventana::dispose);
    }

    private static boolean haySimboloO(char[][] tablero) {
        for (char[] fila : tablero) {
            for (char casilla : fila) {
                if (casilla == 'O') {
                    return true;
                }
            }
        }
        return false;
    }

    private static String etiquetaResultado(VentanaJuego ventana) {
        for (Component componente : ventana.getPanelInformacion().getComponents()) {
            if (componente instanceof JLabel etiqueta && etiqueta.getText().startsWith("Resultado:")) {
                return etiqueta.getText();
            }
        }
        return "";
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}