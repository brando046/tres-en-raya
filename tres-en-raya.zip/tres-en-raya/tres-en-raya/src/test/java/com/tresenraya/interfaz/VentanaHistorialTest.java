package com.tresenraya.interfaz;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;

import javax.swing.SwingUtilities;

import com.tresenraya.modelo.Jugador;
import com.tresenraya.persistencia.HistorialFichero;
import com.tresenraya.persistencia.ResultadoPartida;

public class VentanaHistorialTest {
    public static void main(String[] args) throws Exception {
        Path fichero = Files.createTempFile("tres-en-raya-historial-ui", ".txt");
        Files.deleteIfExists(fichero);
        try {
            HistorialFichero historial = new HistorialFichero(fichero);
            Jugador jugadorX = new Jugador("Ana", 'X', true);
            Jugador jugadorO = new Jugador("Luis", 'O', true);
            historial.guardar(new ResultadoPartida(jugadorX, jugadorO, jugadorX, 5,
                    LocalDateTime.of(2026, 9, 25, 10, 7, 19)));
            historial.guardar(new ResultadoPartida(jugadorX, jugadorO, null, 9,
                    LocalDateTime.of(2026, 9, 25, 10, 8, 19)));

            final VentanaHistorial[] resultado = new VentanaHistorial[1];
            SwingUtilities.invokeAndWait(() -> resultado[0] = new VentanaHistorial(new HistorialFichero(fichero)));
            VentanaHistorial ventana = resultado[0];
            comprobar(ventana.getListaResultados().getModel().getSize() == 2,
                    "No se mostraron las dos partidas guardadas");
            SwingUtilities.invokeAndWait(() -> ventana.getListaResultados().setSelectedIndex(1));
            comprobar(ventana.getGanador().getText().equals("Ganador: Empate"), "No se mostró el empate seleccionado");
            comprobar(ventana.getMovimientos().getText().equals("Movimientos: 9"), "No se mostró el contador seleccionado");
            comprobar(ventana.getJugadorX().getText().equals("Jugador X: Ana"), "No se mostró jugador X");
            comprobar(ventana.getJugadorO().getText().equals("Jugador O: Luis"), "No se mostró jugador O");
                comprobar(ventana.getBotonVerPartida().isEnabled(), "Ver partida no se habilitó");
                comprobar(ventana.getEstado().getText().contains("movimientos"),
                    "No se indicó que faltan movimientos para reconstruir");
                    SwingUtilities.invokeAndWait(ventana.getBotonVerPartida()::doClick);
                    comprobar(ventana.getVentanaPartidaCargada() != null
                        && ventana.getVentanaPartidaCargada().isVisible(),
                        "Ver partida no abrió VentanaPartidaCargada");
                    SwingUtilities.invokeAndWait(ventana.getVentanaPartidaCargada()::dispose);
            SwingUtilities.invokeAndWait(ventana::dispose);
            System.out.println("Prueba de consulta de historial superada");
        } finally {
            Files.deleteIfExists(fichero);
        }
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}