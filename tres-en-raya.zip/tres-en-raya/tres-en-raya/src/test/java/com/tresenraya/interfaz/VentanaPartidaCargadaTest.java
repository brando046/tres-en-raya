package com.tresenraya.interfaz;

import java.time.LocalDateTime;
import java.util.List;

import javax.swing.SwingUtilities;

import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.Movimiento;
import com.tresenraya.persistencia.PartidaGuardada;
import com.tresenraya.persistencia.ResultadoPartida;

public class VentanaPartidaCargadaTest {
    public static void main(String[] args) throws Exception {
        Jugador jugadorX = new Jugador("Jugador X", 'X', true);
        Jugador jugadorO = new Jugador("Jugador O", 'O', true);
        List<Movimiento> movimientos = List.of(
                new Movimiento(0, 0, jugadorX),
                new Movimiento(1, 1, jugadorO),
                new Movimiento(0, 1, jugadorX),
                new Movimiento(2, 2, jugadorO),
                new Movimiento(0, 2, jugadorX),
                new Movimiento(2, 0, jugadorO),
                new Movimiento(1, 0, jugadorX));
        PartidaGuardada partida = new PartidaGuardada(
                new ResultadoPartida(jugadorX, jugadorO, jugadorX, 7,
                        LocalDateTime.of(2026, 9, 25, 10, 7, 19, 86659700)),
                movimientos);
        final VentanaPartidaCargada[] resultado = new VentanaPartidaCargada[1];
        SwingUtilities.invokeAndWait(() -> resultado[0] = new VentanaPartidaCargada(partida));
        VentanaPartidaCargada ventana = resultado[0];

        comprobar("X".equals(ventana.getPanelTablero().getBoton(0, 0).getText()), "Falta X en 0,0");
        comprobar("O".equals(ventana.getPanelTablero().getBoton(1, 1).getText()), "Falta O en 1,1");
        comprobar("X".equals(ventana.getPanelTablero().getBoton(0, 2).getText()), "Falta X en 0,2");
        comprobar("O".equals(ventana.getPanelTablero().getBoton(2, 0).getText()), "Falta O en 2,0");
        comprobar("X".equals(ventana.getPanelTablero().getBoton(1, 0).getText()), "Falta X en 1,0");
        comprobar(!ventana.getPanelTablero().getBoton(2, 1).isEnabled(), "El tablero cargado se puede modificar");
        comprobar(ventana.getEstado().getText().contains("solo lectura"), "No se indicó solo lectura");

        SwingUtilities.invokeAndWait(ventana::dispose);
        System.out.println("Prueba de reconstrucción de tablero superada");
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}