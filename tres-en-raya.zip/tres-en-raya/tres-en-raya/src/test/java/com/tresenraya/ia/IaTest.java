package com.tresenraya.ia;

import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;

public class IaTest {
    public static void main(String[] args) {
        comprobarIaFacil();
        comprobarIaMediaGana();
        comprobarIaMediaBloquea();
        comprobarIaDificil();
        System.out.println("Pruebas de IA superadas");
    }

    private static void comprobarIaFacil() {
        Partida partida = partidaConIa();
        Movimiento movimiento = new IaFacil().decidirMovimiento(partida);

        comprobar(partida.estaLibre(movimiento.getFila(), movimiento.getColumna()),
            "IaFacil no eligió una casilla libre");
        comprobar(partida.numeroMovimientos() == 0, "La IA modificó la partida al decidir");
        partida.marcar(movimiento.getFila(), movimiento.getColumna());
        comprobar(partida.tablero()[movimiento.getFila()][movimiento.getColumna()] == 'X',
            "La jugada de IaFacil no se aplicó en el modelo");
    }

    private static void comprobarIaMediaGana() {
        Partida partida = partidaConIa();
        partida.marcar(0, 0);
        partida.marcar(1, 0);
        partida.marcar(0, 1);
        partida.marcar(1, 1);

        Movimiento movimiento = new IaMedia().decidirMovimiento(partida);

        comprobar(movimiento.getFila() == 0 && movimiento.getColumna() == 2,
                "IaMedia no aprovechó una victoria inmediata");
        partida.marcar(movimiento.getFila(), movimiento.getColumna());
        comprobar(partida.ganador() == partida.turnoActual(), "La jugada ganadora no terminó la partida");
    }

    private static void comprobarIaMediaBloquea() {
        Partida partida = partidaConIa();
        partida.marcar(2, 2);
        partida.marcar(0, 0);
        partida.marcar(1, 0);
        partida.marcar(0, 1);

        Movimiento movimiento = new IaMedia().decidirMovimiento(partida);

        comprobar(movimiento.getFila() == 0 && movimiento.getColumna() == 2,
                "IaMedia no bloqueó la victoria rival");
    }

    private static void comprobarIaDificil() {
        Partida partidaInicial = partidaConIa();
        Movimiento apertura = new IaDificil().decidirMovimiento(partidaInicial);
        comprobar(apertura.getFila() == 1 && apertura.getColumna() == 1,
                "IaDificil no priorizó el centro en la apertura");

        Partida partida = partidaConIa();
        partida.marcar(0, 0);
        partida.marcar(1, 0);
        partida.marcar(0, 1);
        partida.marcar(1, 1);
        Movimiento victoria = new IaDificil().decidirMovimiento(partida);
        comprobar(victoria.getFila() == 0 && victoria.getColumna() == 2,
                "IaDificil no eligió la victoria inmediata");
        partida.marcar(victoria.getFila(), victoria.getColumna());
        comprobar(partida.haTerminado() && partida.ganador().getSimbolo() == 'X',
                "IaDificil no produjo una victoria en el modelo");
    }

    private static Partida partidaConIa() {
        return new Partida(new Jugador("IA", 'X', false), new Jugador("Persona", 'O', true));
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}