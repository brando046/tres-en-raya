package com.tresenraya.persistencia;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;

import com.tresenraya.modelo.Jugador;

public class HistorialFicheroResultadosTest {
    public static void main(String[] args) throws Exception {
        Path fichero = Files.createTempFile("tres-en-raya-resultados", ".txt");
        Files.deleteIfExists(fichero);
        try {
            Jugador jugadorX = new Jugador("Jugador X", 'X', true);
            Jugador jugadorO = new Jugador("Jugador O", 'O', true);
            HistorialFichero historial = new HistorialFichero(fichero);
            historial.guardar(new ResultadoPartida(jugadorX, jugadorO, jugadorX, 5,
                    LocalDateTime.of(2026, 9, 25, 10, 10, 1)));
            historial.guardar(new ResultadoPartida(jugadorX, jugadorO, jugadorO, 6,
                    LocalDateTime.of(2026, 9, 25, 10, 10, 2)));
            historial.guardar(new ResultadoPartida(jugadorX, jugadorO, null, 9,
                    LocalDateTime.of(2026, 9, 25, 10, 10, 3)));

            HistorialFichero historialReabierto = new HistorialFichero(fichero);
            comprobar(historialReabierto.cargarPartidas().size() == 3,
                    "No se conservaron las tres partidas terminadas");
            comprobar(historialReabierto.cargarPartidas().get(0).getGanador().getSimbolo() == 'X',
                    "No se cargó la victoria de X");
            comprobar(historialReabierto.cargarPartidas().get(1).getGanador().getSimbolo() == 'O',
                    "No se cargó la victoria de O");
            comprobar(historialReabierto.cargarPartidas().get(2).getGanador() == null,
                    "No se cargó el empate");
            comprobar(Files.readAllLines(fichero).size() == 3,
                    "El fichero no contiene una línea por resultado final");
            System.out.println("Pruebas de victorias y empate en fichero superadas");
        } finally {
            Files.deleteIfExists(fichero);
        }
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}
