package com.tresenraya.persistencia;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;

import com.tresenraya.modelo.Jugador;

public class HistorialFicheroTest {
    public static void main(String[] args) throws Exception {
        Path fichero = Files.createTempFile("tres-en-raya-historial", ".txt");
        Files.deleteIfExists(fichero);
        try {
            Jugador jugadorX = new Jugador("Ana", 'X', true);
            Jugador jugadorO = new Jugador("Máquina", 'O', false);
            ResultadoPartida resultado = new ResultadoPartida(jugadorX, jugadorO, null, 9,
                    LocalDateTime.of(2026, 9, 25, 10, 7, 19, 86659700));
            HistorialFichero primerHistorial = new HistorialFichero(fichero);

            comprobar(Files.exists(fichero), "No se creó historial.txt");
            primerHistorial.guardar(resultado);
            HistorialFichero segundoHistorial = new HistorialFichero(fichero);

            comprobar(segundoHistorial.cargarPartidas().size() == 1,
                    "El resultado no sobrevivió a una nueva instancia");
            ResultadoPartida cargado = segundoHistorial.cargarPartidas().get(0);
            comprobar(cargado.getJugadorX().getNombre().equals("Ana"), "No se cargó jugador X");
            comprobar(cargado.getJugadorO().getNombre().equals("Máquina"), "No se cargó jugador O");
            comprobar(cargado.getGanador() == null, "El empate no se cargó correctamente");
            comprobar(cargado.getNumeroMovimientos() == 9, "No se cargó el contador");
            comprobar(cargado.getFecha().equals(resultado.getFecha()), "No se cargó la fecha ISO");
            System.out.println("Prueba de persistencia en fichero superada");
        } finally {
            Files.deleteIfExists(fichero);
        }
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}