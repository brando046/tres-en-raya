package com.tresenraya.interfaz;

import java.awt.Component;
import java.awt.Container;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

import com.tresenraya.modelo.Dificultad;

public class VentanaDificultadTest {
    public static void main(String[] args) throws Exception {
        List<Dificultad> selecciones = new ArrayList<>();
        VentanaDificultad ventana = crearVentana(selecciones);

        pulsarBoton(ventana, "Fácil");
        comprobar(selecciones.get(0) == Dificultad.FACIL, "La opción Fácil no fue comunicada");
        pulsarBoton(ventana, "Media");
        comprobar(selecciones.get(1) == Dificultad.MEDIA, "La opción Media no fue comunicada");
        pulsarBoton(ventana, "Difícil");
        comprobar(selecciones.get(2) == Dificultad.DIFICIL, "La opción Difícil no fue comunicada");
        comprobar(ventana.getDificultadSeleccionada() == Dificultad.DIFICIL,
                "La última dificultad no quedó guardada");

        ventana.dispose();
        System.out.println("Pruebas de VentanaDificultad superadas");
    }

    private static VentanaDificultad crearVentana(List<Dificultad> selecciones) throws Exception {
        final VentanaDificultad[] resultado = new VentanaDificultad[1];
        SwingUtilities.invokeAndWait(() -> resultado[0] = new VentanaDificultad(selecciones::add));
        return resultado[0];
    }

    private static void pulsarBoton(VentanaDificultad ventana, String texto) throws Exception {
        JButton boton = buscarBoton(ventana.getContentPane(), texto);
        comprobar(boton != null, "No se encontró el botón " + texto);
        SwingUtilities.invokeAndWait(boton::doClick);
    }

    private static JButton buscarBoton(Container contenedor, String texto) {
        for (Component componente : contenedor.getComponents()) {
            if (componente instanceof JButton boton && texto.equals(boton.getText())) {
                return boton;
            }
            if (componente instanceof Container hijo) {
                JButton boton = buscarBoton(hijo, texto);
                if (boton != null) {
                    return boton;
                }
            }
        }
        return null;
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}