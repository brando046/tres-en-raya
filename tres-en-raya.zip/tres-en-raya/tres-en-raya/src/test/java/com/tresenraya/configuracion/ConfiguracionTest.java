package com.tresenraya.configuracion;

public class ConfiguracionTest {
    public static void main(String[] args) {
        Configuracion configuracion = new Configuracion();

        configuracion.setNombreJugadorX("Ana");
        configuracion.setNombreJugadorO("Luis");

        comprobar(configuracion.getNombreJugadorX().equals("Ana"),
                "No se consultó el nombre de X");
        comprobar(configuracion.getNombreJugadorO().equals("Luis"),
                "No se consultó el nombre de O");

        System.out.println("Prueba de configuración superada");
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}