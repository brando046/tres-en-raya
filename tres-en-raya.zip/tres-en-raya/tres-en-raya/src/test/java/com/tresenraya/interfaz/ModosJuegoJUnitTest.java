package com.tresenraya.interfaz;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeFalse;

import java.awt.GraphicsEnvironment;
import java.util.List;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

import org.junit.jupiter.api.Test;

import com.tresenraya.configuracion.Configuracion;
import com.tresenraya.ia.IaDificil;
import com.tresenraya.ia.IaFacil;
import com.tresenraya.ia.IaMedia;
import com.tresenraya.modelo.Dificultad;
import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.ModoJuego;
import com.tresenraya.modelo.Partida;
import com.tresenraya.persistencia.HistorialConsola;

class ModosJuegoJUnitTest {
	@Test
	void jugadorVsJugadorMantieneDosTurnosHumanosYGuardaNombres() throws Exception {
		asumeEntornoGrafico();
		Configuracion configuracion = new Configuracion();
		configuracion.setJugadorX("Brandon");
		configuracion.setJugadorO("Luisa");
		HistorialConsola historial = new HistorialConsola();
		VentanaJuego juego = crearJuego(ModoJuego.JUGADOR_VS_JUGADOR, configuracion, null, historial);
		try {
			assertNull(juego.getInteligenciaArtificial());
			assertNull(juego.getDificultad());
			assertTrue(juego.getPartida().jugadorX().esHumano());
			assertTrue(juego.getPartida().jugadorO().esHumano());
			assertEquals("Modo: JUGADOR VS JUGADOR", juego.getPanelInformacion().getEtiquetaModo().getText());
			assertFalse(juego.getPanelInformacion().getEtiquetaModo().getText().contains("Dificultad"));
			jugar(juego, 0, 0);
			assertEquals('O', juego.getPartida().turnoActual().getSimbolo());
			jugar(juego, 1, 1);
			assertEquals('X', juego.getPartida().turnoActual().getSimbolo());
			jugar(juego, 0, 1);
			jugar(juego, 2, 0);
			jugar(juego, 0, 2);
			assertEquals('X', juego.getPartida().ganador().getSimbolo());
			assertEquals(List.of("Brandon", "Luisa"), List.of(
					juego.getResultadoRegistrado().getJugadorX().getNombre(),
					juego.getResultadoRegistrado().getJugadorO().getNombre()));
			assertEquals(1, historial.getResultados().size());
		} finally {
			cerrar(juego);
		}
	}

	@Test
	void jugadorVsIaRespondeConCadaDificultad() throws Exception {
		asumeEntornoGrafico();
		List<Class<?>> tiposIa = List.of(IaFacil.class, IaMedia.class, IaDificil.class);
		for (int indice = 0; indice < Dificultad.values().length; indice++) {
			Dificultad dificultad = Dificultad.values()[indice];
			VentanaJuego juego = crearJuego(ModoJuego.JUGADOR_VS_IA, new Configuracion(), dificultad,
					new HistorialConsola());
			try {
				assertEquals(ModoJuego.JUGADOR_VS_IA, juego.getModoJuego());
				assertEquals(dificultad, juego.getDificultad());
				assertInstanceOf(tiposIa.get(indice), juego.getInteligenciaArtificial());
				assertTrue(juego.getPanelInformacion().getEtiquetaModo().getText()
						.contains("Dificultad: " + textoDificultad(dificultad)));
				jugar(juego, 0, 0);
				assertEquals(2, juego.getPartida().numeroMovimientos());
				assertEquals('X', juego.getPartida().turnoActual().getSimbolo());
			} finally {
				cerrar(juego);
			}
		}
	}

	@Test
	void ambosModosDetectanEmpateYGuardanResultado() throws Exception {
		asumeEntornoGrafico();
		int[][] jugadasEmpate = {
				{0, 0}, {0, 1}, {0, 2},
				{1, 1}, {1, 0}, {1, 2},
				{2, 1}, {2, 0}, {2, 2}
		};
		VentanaJuego local = crearJuego(ModoJuego.JUGADOR_VS_JUGADOR,
				new Partida(new Jugador("Ana", 'X', true), new Jugador("Luis", 'O', true)),
				null, new HistorialConsola());
		try {
			for (int[] jugada : jugadasEmpate) {
				jugar(local, jugada[0], jugada[1]);
			}
			assertTrue(local.getPartida().hayEmpate());
			assertEquals(9, local.getResultadoRegistrado().getNumeroMovimientos());
		} finally {
			cerrar(local);
		}

		Partida partidaIa = partidaConEmpateInminente();
		HistorialConsola historialIa = new HistorialConsola();
		VentanaJuego contraIa = crearJuego(ModoJuego.JUGADOR_VS_IA, partidaIa, Dificultad.MEDIA, historialIa);
		try {
			jugar(contraIa, 2, 2);
			assertTrue(partidaIa.hayEmpate());
			assertEquals(1, historialIa.getResultados().size());
		} finally {
			cerrar(contraIa);
		}
	}

	@Test
	void jugadorVsIaGuardaVictoriaYNoAceptaMovimientosPosteriores() throws Exception {
		asumeEntornoGrafico();
		Jugador humano = new Jugador("Brandon", 'X', true);
		Jugador ia = new Jugador("IA", 'O', false);
		Partida partida = new Partida(humano, ia);
		partida.marcar(0, 0);
		partida.marcar(1, 0);
		partida.marcar(0, 1);
		partida.marcar(1, 1);
		HistorialConsola historial = new HistorialConsola();
		VentanaJuego juego = crearJuego(ModoJuego.JUGADOR_VS_IA, partida, Dificultad.DIFICIL, historial);
		try {
			jugar(juego, 0, 2);
			assertEquals('X', partida.ganador().getSimbolo());
			assertEquals(1, historial.getResultados().size());
			int movimientos = partida.numeroMovimientos();
			jugar(juego, 2, 2);
			assertEquals(movimientos, partida.numeroMovimientos());
		} finally {
			cerrar(juego);
		}
	}

	@Test
	void navegarPorSelectorPermiteVolverDeDificultadAlModo() throws Exception {
		asumeEntornoGrafico();
		VentanaInicio inicio = new VentanaInicio(new HistorialConsola());
		SwingUtilities.invokeAndWait(() -> {
			inicio.setVisible(true);
			boton(inicio, "Nueva partida").doClick();
		});
		try {
			assertTrue(inicio.getVentanaModoJuego().isVisible());
			SwingUtilities.invokeAndWait(() -> boton(inicio.getVentanaModoJuego(), "Jugador vs IA").doClick());
			assertTrue(inicio.getVentanaDificultad().isVisible());
			SwingUtilities.invokeAndWait(() -> inicio.getVentanaDificultad().getBotonVolver().doClick());
			assertTrue(inicio.getVentanaModoJuego().isVisible());
			assertFalse(inicio.isVisible());
			SwingUtilities.invokeAndWait(() -> inicio.getVentanaModoJuego().getBotonVolver().doClick());
			assertTrue(inicio.isVisible());
			SwingUtilities.invokeAndWait(() -> boton(inicio, "Nueva partida").doClick());
			assertTrue(inicio.getVentanaModoJuego().isVisible());
			SwingUtilities.invokeAndWait(() -> boton(inicio.getVentanaModoJuego(), "Jugador vs Jugador").doClick());
			assertTrue(inicio.getVentanaJuego().isVisible());
			assertEquals(ModoJuego.JUGADOR_VS_JUGADOR, inicio.getVentanaJuego().getModoJuego());
		} finally {
			SwingUtilities.invokeAndWait(() -> {
				if (inicio.getVentanaJuego() != null) {
					inicio.getVentanaJuego().dispose();
				}
				if (inicio.getVentanaDificultad() != null) {
					inicio.getVentanaDificultad().dispose();
				}
				if (inicio.getVentanaModoJuego() != null) {
					inicio.getVentanaModoJuego().dispose();
				}
				inicio.dispose();
			});
		}
	}

	private static void asumeEntornoGrafico() {
		assumeFalse(GraphicsEnvironment.isHeadless(), "Las pruebas Swing requieren un entorno gráfico");
	}

	private static VentanaJuego crearJuego(ModoJuego modo, Configuracion configuracion,
			Dificultad dificultad, HistorialConsola historial) throws Exception {
		VentanaJuego[] resultado = new VentanaJuego[1];
		SwingUtilities.invokeAndWait(() -> resultado[0] = new VentanaJuego(modo, configuracion, dificultad, historial));
		return resultado[0];
	}

	private static VentanaJuego crearJuego(ModoJuego modo, Partida partida,
			Dificultad dificultad, HistorialConsola historial) throws Exception {
		VentanaJuego[] resultado = new VentanaJuego[1];
		SwingUtilities.invokeAndWait(() -> resultado[0] = new VentanaJuego(partida, modo, dificultad, historial));
		return resultado[0];
	}

	private static Partida partidaConEmpateInminente() {
		Jugador x = new Jugador("X", 'X', true);
		Jugador o = new Jugador("O", 'O', false);
		Partida partida = new Partida(x, o);
		int[][] jugadas = {
				{0, 0}, {0, 1}, {0, 2},
				{1, 1}, {1, 0}, {1, 2},
				{2, 1}, {2, 0}
		};
		for (int[] jugada : jugadas) {
			partida.marcar(jugada[0], jugada[1]);
		}
		return partida;
	}

	private static void jugar(VentanaJuego juego, int fila, int columna) throws Exception {
		SwingUtilities.invokeAndWait(() -> juego.getPanelTablero().getBoton(fila, columna).doClick());
	}

	private static void cerrar(VentanaJuego juego) throws Exception {
		SwingUtilities.invokeAndWait(juego::dispose);
	}

	private static String textoDificultad(Dificultad dificultad) {
		return switch (dificultad) {
			case FACIL -> "Fácil";
			case MEDIA -> "Media";
			case DIFICIL -> "Difícil";
		};
	}

	private static JButton boton(VentanaModoJuego ventana, String texto) {
		for (java.awt.Component componente : ventana.getContentPane().getComponents()) {
			JButton encontrado = buscarBoton(componente, texto);
			if (encontrado != null) {
				return encontrado;
			}
		}
		throw new AssertionError("No se encontró el botón " + texto);
	}

	private static JButton boton(VentanaInicio ventana, String texto) {
		for (java.awt.Component componente : ventana.getContentPane().getComponents()) {
			JButton encontrado = buscarBoton(componente, texto);
			if (encontrado != null) {
				return encontrado;
			}
		}
		throw new AssertionError("No se encontró el botón " + texto);
	}

	private static JButton buscarBoton(java.awt.Component componente, String texto) {
		if (componente instanceof JButton boton && texto.equals(boton.getText())) {
			return boton;
		}
		if (componente instanceof java.awt.Container contenedor) {
			for (java.awt.Component hijo : contenedor.getComponents()) {
				JButton encontrado = buscarBoton(hijo, texto);
				if (encontrado != null) {
					return encontrado;
				}
			}
		}
		return null;
	}
}
