package com.tresenraya;

import javax.swing.SwingUtilities;

import com.tresenraya.interfaz.VentanaInicio;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaInicio().setVisible(true));
    }
}
