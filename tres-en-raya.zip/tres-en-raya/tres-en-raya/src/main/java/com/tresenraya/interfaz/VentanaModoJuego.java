package com.tresenraya.interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Objects;
import java.util.function.Consumer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.tresenraya.modelo.ModoJuego;

public class VentanaModoJuego extends JFrame {
	private final Consumer<ModoJuego> alSeleccionar;
	private final Runnable alVolver;
	private final JButton botonJugadorVsJugador = new JButton("Jugador vs Jugador");
	private final JButton botonJugadorVsIa = new JButton("Jugador vs IA");
	private final JButton botonVolver = new JButton("Volver");

	public VentanaModoJuego(Consumer<ModoJuego> alSeleccionar, Runnable alVolver) {
		super("Nueva partida");
		this.alSeleccionar = Objects.requireNonNull(alSeleccionar, "La acción de selección no puede ser nula");
		this.alVolver = Objects.requireNonNull(alVolver, "La acción de volver no puede ser nula");
		construirVentana();
	}

	private void construirVentana() {
		JPanel panelPrincipal = new JPanel(new BorderLayout(14, 16));
		panelPrincipal.setPreferredSize(new Dimension(480, 380));
		panelPrincipal.setBorder(BorderFactory.createEmptyBorder(24, 30, 22, 30));

		JLabel titulo = new JLabel("NUEVA PARTIDA", SwingConstants.CENTER);
		titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 25f));
		panelPrincipal.add(titulo, BorderLayout.NORTH);

		JPanel opciones = new JPanel(new GridLayout(3, 1, 10, 10));
		JLabel instruccion = new JLabel("Selecciona el modo de juego", SwingConstants.CENTER);
		instruccion.setFont(instruccion.getFont().deriveFont(16f));
		opciones.add(instruccion);
		configurarBoton(botonJugadorVsJugador, 'J');
		configurarBoton(botonJugadorVsIa, 'I');
		opciones.add(botonJugadorVsJugador);
		opciones.add(botonJugadorVsIa);
		panelPrincipal.add(opciones, BorderLayout.CENTER);

		botonVolver.setMnemonic('V');
		botonVolver.setFocusable(true);
		botonVolver.setFocusPainted(true);
		botonVolver.setFont(botonVolver.getFont().deriveFont(15f));
		botonVolver.setPreferredSize(new Dimension(130, 42));
		JPanel panelVolver = new JPanel();
		panelVolver.add(botonVolver);
		panelPrincipal.add(panelVolver, BorderLayout.SOUTH);

		botonJugadorVsJugador.addActionListener(event -> seleccionarModo(ModoJuego.JUGADOR_VS_JUGADOR));
		botonJugadorVsIa.addActionListener(event -> seleccionarModo(ModoJuego.JUGADOR_VS_IA));
		botonVolver.addActionListener(event -> alVolver.run());
		setContentPane(panelPrincipal);
		setFocusTraversalPolicyProvider(true);
		setFocusTraversalPolicy(new LayoutFocusTraversalPolicy());
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		pack();
		setMinimumSize(getSize());
		setLocationRelativeTo(null);
		setResizable(false);
	}

	private void configurarBoton(JButton boton, char mnemonic) {
		boton.setMnemonic(mnemonic);
		boton.setFocusable(true);
		boton.setFocusPainted(true);
		boton.setFont(boton.getFont().deriveFont(Font.BOLD, 17f));
		boton.setPreferredSize(new Dimension(360, 52));
	}

	public void seleccionarModo(ModoJuego modoJuego) {
		alSeleccionar.accept(Objects.requireNonNull(modoJuego, "El modo de juego no puede ser nulo"));
	}

	public JButton getBotonJugadorVsJugador() {
		return botonJugadorVsJugador;
	}

	public JButton getBotonJugadorVsIa() {
		return botonJugadorVsIa;
	}

	public JButton getBotonVolver() {
		return botonVolver;
	}
}
