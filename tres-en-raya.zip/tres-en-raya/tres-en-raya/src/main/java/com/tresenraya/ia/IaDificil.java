package com.tresenraya.ia;

import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;

public class IaDificil implements InteligenciaArtificial {
	@Override
	public Movimiento decidirMovimiento(Partida partida) {
		IaUtilidades.validarPartida(partida);
		char[][] tablero = partida.tablero();
		char simboloIa = partida.turnoActual().getSimbolo();
		char simboloRival = simboloIa == 'X' ? 'O' : 'X';
		int mejorPuntuacion = Integer.MIN_VALUE;
		int mejorFila = -1;
		int mejorColumna = -1;

		for (int[] posicion : IaUtilidades.ordenDeBusqueda()) {
			int fila = posicion[0];
			int columna = posicion[1];
			if (tablero[fila][columna] == '\0') {
				tablero[fila][columna] = simboloIa;
				int puntuacion = minimax(tablero, simboloIa, simboloRival, false, 0);
				tablero[fila][columna] = '\0';
				if (puntuacion > mejorPuntuacion) {
					mejorPuntuacion = puntuacion;
					mejorFila = fila;
					mejorColumna = columna;
				}
			}
		}
		if (mejorFila < 0) {
			throw new IllegalStateException("No quedan movimientos disponibles");
		}
		return new Movimiento(mejorFila, mejorColumna, partida.turnoActual());
	}

	private int minimax(char[][] tablero, char simboloIa, char simboloRival, boolean maximizar, int profundidad) {
		if (IaUtilidades.hayLinea(tablero, simboloIa)) {
			return 10 - profundidad;
		}
		if (IaUtilidades.hayLinea(tablero, simboloRival)) {
			return profundidad - 10;
		}
		if (!IaUtilidades.hayCasillasLibres(tablero)) {
			return 0;
		}

		int mejorPuntuacion = maximizar ? Integer.MIN_VALUE : Integer.MAX_VALUE;
		for (int[] posicion : IaUtilidades.ordenDeBusqueda()) {
			int fila = posicion[0];
			int columna = posicion[1];
			if (tablero[fila][columna] == '\0') {
				tablero[fila][columna] = maximizar ? simboloIa : simboloRival;
				int puntuacion = minimax(tablero, simboloIa, simboloRival, !maximizar, profundidad + 1);
				tablero[fila][columna] = '\0';
				mejorPuntuacion = maximizar
						? Math.max(mejorPuntuacion, puntuacion)
						: Math.min(mejorPuntuacion, puntuacion);
			}
		}
		return mejorPuntuacion;
	}
}
