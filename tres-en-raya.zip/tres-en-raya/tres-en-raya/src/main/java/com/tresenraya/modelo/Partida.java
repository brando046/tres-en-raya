package com.tresenraya.modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.tresenraya.util.Constantes;

public class Partida {
	private final char[][] tablero = new char[Constantes.TAMANO_TABLERO][Constantes.TAMANO_TABLERO];
	private final Jugador primerJugador;
	private final Jugador segundoJugador;
	private final List<Movimiento> movimientos = new ArrayList<>();
	private Jugador turnoActual;
	private Jugador ganador;
	private boolean empate;

	public Partida(Jugador primerJugador, Jugador segundoJugador) {
		if (primerJugador == null || segundoJugador == null) {
			throw new IllegalArgumentException("Los jugadores no pueden ser nulos");
		}
		if (primerJugador.getSimbolo() == segundoJugador.getSimbolo()) {
			throw new IllegalArgumentException("Los jugadores deben tener simbolos distintos");
		}
		this.primerJugador = primerJugador;
		this.segundoJugador = segundoJugador;
		this.turnoActual = primerJugador;
	}

	public boolean estaLibre(int fila, int columna) {
		validarCoordenadas(fila, columna);
		return tablero[fila][columna] == '\0';
	}

	public Movimiento marcar(int fila, int columna) {
		validarCoordenadas(fila, columna);
		if (haTerminado()) {
			throw new IllegalStateException("La partida ya ha terminado");
		}
		if (!estaLibre(fila, columna)) {
			throw new IllegalArgumentException("La casilla ya esta ocupada");
		}

		Movimiento movimiento = new Movimiento(fila, columna, turnoActual);
		tablero[fila][columna] = turnoActual.getSimbolo();
		movimientos.add(movimiento);
		actualizarEstado(turnoActual);
		if (!haTerminado()) {
			turnoActual = otroJugador(turnoActual);
		}
		return movimiento;
	}

	public boolean haTerminado() {
		return ganador != null || empate;
	}

	public Jugador ganador() {
		return ganador;
	}

	public boolean hayEmpate() {
		return empate;
	}

	public Jugador turnoActual() {
		return turnoActual;
	}

	public Jugador jugadorX() {
		return primerJugador.getSimbolo() == 'X' ? primerJugador : segundoJugador;
	}

	public Jugador jugadorO() {
		return primerJugador.getSimbolo() == 'O' ? primerJugador : segundoJugador;
	}

	public int numeroMovimientos() {
		return movimientos.size();
	}

	public void reiniciar() {
		for (int fila = 0; fila < Constantes.TAMANO_TABLERO; fila++) {
			for (int columna = 0; columna < Constantes.TAMANO_TABLERO; columna++) {
				tablero[fila][columna] = '\0';
			}
		}
		movimientos.clear();
		turnoActual = primerJugador;
		ganador = null;
		empate = false;
	}

	public List<Movimiento> movimientos() {
		return Collections.unmodifiableList(movimientos);
	}

	public char[][] tablero() {
		char[][] copia = new char[Constantes.TAMANO_TABLERO][Constantes.TAMANO_TABLERO];
		for (int fila = 0; fila < Constantes.TAMANO_TABLERO; fila++) {
			System.arraycopy(tablero[fila], 0, copia[fila], 0, Constantes.TAMANO_TABLERO);
		}
		return copia;
	}

	private void actualizarEstado(Jugador jugador) {
		if (hayLineaGanadora(jugador.getSimbolo())) {
			ganador = jugador;
		} else if (movimientos.size() == Constantes.TAMANO_TABLERO * Constantes.TAMANO_TABLERO) {
			empate = true;
		}
	}

	private boolean hayLineaGanadora(char simbolo) {
		for (int indice = 0; indice < Constantes.TAMANO_TABLERO; indice++) {
			if ((tablero[indice][0] == simbolo && tablero[indice][1] == simbolo && tablero[indice][2] == simbolo)
					|| (tablero[0][indice] == simbolo && tablero[1][indice] == simbolo && tablero[2][indice] == simbolo)) {
				return true;
			}
		}
		return (tablero[0][0] == simbolo && tablero[1][1] == simbolo && tablero[2][2] == simbolo)
				|| (tablero[0][2] == simbolo && tablero[1][1] == simbolo && tablero[2][0] == simbolo);
	}

	private Jugador otroJugador(Jugador jugador) {
		return jugador == primerJugador ? segundoJugador : primerJugador;
	}

	private void validarCoordenadas(int fila, int columna) {
		if (fila < 0 || fila >= Constantes.TAMANO_TABLERO
				|| columna < 0 || columna >= Constantes.TAMANO_TABLERO) {
			throw new IllegalArgumentException("Las coordenadas deben estar entre 0 y 2");
		}
	}
}
