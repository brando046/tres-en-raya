package com.tresenraya.modelo;

public class Jugador {
	private final String nombre;
	private final char simbolo;
	private final boolean humano;

	public Jugador(String nombre, char simbolo, boolean humano) {
		if (nombre == null || nombre.isBlank()) {
			throw new IllegalArgumentException("El nombre no puede estar vacio");
		}
		char simboloNormalizado = Character.toUpperCase(simbolo);
		if (simboloNormalizado != 'X' && simboloNormalizado != 'O') {
			throw new IllegalArgumentException("El simbolo debe ser X u O");
		}
		this.nombre = nombre;
		this.simbolo = simboloNormalizado;
		this.humano = humano;
	}

	public String getNombre() {
		return nombre;
	}

	public char getSimbolo() {
		return simbolo;
	}

	public boolean esHumano() {
		return humano;
	}

	public boolean esIa() {
		return !humano;
	}
}
