package com.tresenraya.modelo;

public class Movimiento {
	private final int fila;
	private final int columna;
	private final Jugador jugador;

	public Movimiento(int fila, int columna, Jugador jugador) {
		if (jugador == null) {
			throw new IllegalArgumentException("El jugador no puede ser nulo");
		}
		this.fila = fila;
		this.columna = columna;
		this.jugador = jugador;
	}

	public int getFila() {
		return fila;
	}

	public int getColumna() {
		return columna;
	}

	public Jugador getJugador() {
		return jugador;
	}
}
