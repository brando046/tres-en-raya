package com.tresenraya.interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Objects;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.tresenraya.configuracion.Configuracion;

public class VentanaConfiguracion extends JFrame {
    private final Configuracion configuracion;
    private final Runnable alGuardar;
    private JTextField campoJugadorX;
    private JTextField campoJugadorO;
    private JLabel mensajeEstado;
    private JButton botonGuardar;
    private JButton botonVolver;

    public VentanaConfiguracion(Configuracion configuracion) {
        this(configuracion, () -> {
        });
    }

    public VentanaConfiguracion(Configuracion configuracion, Runnable alGuardar) {
        super("Configuración");
        this.configuracion = Objects.requireNonNull(configuracion, "La configuración no puede ser nula");
        this.alGuardar = Objects.requireNonNull(alGuardar, "La acción de guardado no puede ser nula");
        initializeComponents();
        setupLayout();
        setupListeners();
        configurarVentana();
    }

    private void initializeComponents() {
        campoJugadorX = new JTextField(configuracion.getJugadorX(), 18);
        campoJugadorO = new JTextField(configuracion.getJugadorO(), 18);
        mensajeEstado = new JLabel(" ", SwingConstants.CENTER);
        campoJugadorX.setFont(campoJugadorX.getFont().deriveFont(15f));
        campoJugadorO.setFont(campoJugadorO.getFont().deriveFont(15f));
        campoJugadorX.getAccessibleContext().setAccessibleName("Nombre del jugador X");
        campoJugadorO.getAccessibleContext().setAccessibleName("Nombre del jugador O");
    }

    private void setupLayout() {
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 14));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(22, 26, 22, 26));
        JLabel titulo = new JLabel("CONFIGURACIÓN", SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 22f));
        panelPrincipal.add(titulo, BorderLayout.NORTH);

        JPanel formulario = new JPanel(new GridLayout(2, 2, 10, 16));
        JLabel etiquetaJugadorX = new JLabel("Jugador X:");
        etiquetaJugadorX.setFont(etiquetaJugadorX.getFont().deriveFont(15f));
        etiquetaJugadorX.setDisplayedMnemonic('X');
        etiquetaJugadorX.setLabelFor(campoJugadorX);
        formulario.add(etiquetaJugadorX);
        formulario.add(campoJugadorX);
        JLabel etiquetaJugadorO = new JLabel("Jugador O:");
        etiquetaJugadorO.setFont(etiquetaJugadorO.getFont().deriveFont(15f));
        etiquetaJugadorO.setDisplayedMnemonic('O');
        etiquetaJugadorO.setLabelFor(campoJugadorO);
        formulario.add(etiquetaJugadorO);
        formulario.add(campoJugadorO);
        panelPrincipal.add(formulario, BorderLayout.CENTER);

        botonGuardar = new JButton("Guardar");
        botonVolver = new JButton("Volver");
        botonGuardar.setMnemonic('G');
        botonVolver.setMnemonic('V');
        for (JButton boton : new JButton[] {botonGuardar, botonVolver}) {
            boton.setFont(boton.getFont().deriveFont(15f));
            boton.setPreferredSize(new Dimension(120, 42));
        }
        botonGuardar.setFocusable(true);
        botonVolver.setFocusable(true);
        botonGuardar.setFocusPainted(true);
        botonVolver.setFocusPainted(true);
        JPanel acciones = new JPanel(new BorderLayout(5, 5));
        acciones.add(mensajeEstado, BorderLayout.NORTH);
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botones.add(botonGuardar);
        botones.add(botonVolver);
        acciones.add(botones, BorderLayout.CENTER);
        panelPrincipal.add(acciones, BorderLayout.SOUTH);
        setContentPane(panelPrincipal);
        setFocusTraversalPolicyProvider(true);
        setFocusTraversalPolicy(new LayoutFocusTraversalPolicy());
    }

    private void setupListeners() {
        botonGuardar.addActionListener(event -> guardarConfiguracion());
        botonVolver.addActionListener(event -> dispose());
    }

    private void guardarConfiguracion() {
        try {
            configuracion.setJugadorX(campoJugadorX.getText());
            configuracion.setJugadorO(campoJugadorO.getText());
            mensajeEstado.setText("Configuración guardada");
            alGuardar.run();
            dispose();
        } catch (IllegalArgumentException excepcion) {
            mensajeEstado.setText(excepcion.getMessage());
        }
    }

    private void configurarVentana() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pack();
        setMinimumSize(getSize());
        setLocationRelativeTo(null);
        setResizable(false);
    }

    public JTextField getCampoJugadorX() {
        return campoJugadorX;
    }

    public JTextField getCampoJugadorO() {
        return campoJugadorO;
    }
}
