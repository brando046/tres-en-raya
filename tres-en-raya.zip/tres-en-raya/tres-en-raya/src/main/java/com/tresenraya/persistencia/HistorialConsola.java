package com.tresenraya.persistencia;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.tresenraya.modelo.Movimiento;

public class HistorialConsola implements Historial {
	private final List<ResultadoPartida> resultados = new ArrayList<>();
	private final List<PartidaGuardada> partidas = new ArrayList<>();

	@Override
	public void guardar(ResultadoPartida resultado) {
		guardar(resultado, List.of());
	}

	@Override
	public void guardar(ResultadoPartida resultado, List<Movimiento> movimientos) {
		if (resultado == null) {
			throw new IllegalArgumentException("El resultado no puede ser nulo");
		}
		if (movimientos == null) {
			throw new IllegalArgumentException("Los movimientos no pueden ser nulos");
		}
		resultados.add(resultado);
		partidas.add(new PartidaGuardada(resultado, movimientos));
		System.out.println(mensajeGuardado(resultado));
	}

	@Override
	public List<ResultadoPartida> cargarPartidas() {
		return Collections.unmodifiableList(resultados);
	}

	@Override
	public List<ResultadoPartida> obtenerHistorial() {
		return cargarPartidas();
	}

	@Override
	public List<PartidaGuardada> cargarPartidasDetalladas() {
		return Collections.unmodifiableList(partidas);
	}

	public List<ResultadoPartida> getResultados() {
		return cargarPartidas();
	}

	static String mensajeGuardado(ResultadoPartida resultado) {
		String ganador = resultado.getGanador() == null
				? "Empate"
				: "Ganador: " + resultado.getGanador().getSimbolo();
		return "Partida guardada: " + ganador
				+ ", movimientos: " + resultado.getNumeroMovimientos()
				+ ", fecha: " + resultado.getFecha();
	}
}
