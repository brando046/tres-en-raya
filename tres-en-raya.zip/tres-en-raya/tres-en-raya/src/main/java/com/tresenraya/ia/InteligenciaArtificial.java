package com.tresenraya.ia;

import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;

public interface InteligenciaArtificial {
	Movimiento decidirMovimiento(Partida partida);
}
