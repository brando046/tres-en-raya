package com.tresenraya.persistencia;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.Movimiento;

public class HistorialFichero implements Historial {
    private final Path fichero;

    public HistorialFichero() {
        this(Path.of("historial.txt"));
    }

    public HistorialFichero(Path fichero) {
        if (fichero == null) {
            throw new IllegalArgumentException("La ruta del historial no puede ser nula");
        }
        this.fichero = fichero;
        asegurarFichero();
    }

    @Override
    public void guardar(ResultadoPartida resultado) {
		guardar(resultado, List.of());
	}

	@Override
	public void guardar(ResultadoPartida resultado, List<Movimiento> movimientos) {
        if (resultado == null) {
            throw new IllegalArgumentException("El resultado no puede ser nulo");
        }
        if (movimientos == null) {
            throw new IllegalArgumentException("Los movimientos no pueden ser nulos");
        }
        String linea = String.join("|",
                resultado.getJugadorX().getNombre(),
                resultado.getJugadorO().getNombre(),
                resultado.getGanador() == null ? "" : String.valueOf(resultado.getGanador().getSimbolo()),
                String.valueOf(resultado.getNumeroMovimientos()),
                resultado.getFecha().toString(),
                serializarMovimientos(movimientos));
        try {
            Files.writeString(fichero, linea + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        } catch (IOException excepcion) {
            throw new IllegalStateException("No se pudo guardar el historial en " + fichero, excepcion);
        }
        System.out.println(HistorialConsola.mensajeGuardado(resultado));
    }

    @Override
    public List<ResultadoPartida> cargarPartidas() {
        List<ResultadoPartida> resultados = new ArrayList<>();
        for (PartidaGuardada partida : cargarPartidasDetalladas()) {
            resultados.add(partida.getResultado());
        }
        return Collections.unmodifiableList(resultados);
    }

    @Override
    public List<ResultadoPartida> obtenerHistorial() {
        return cargarPartidas();
    }

    @Override
    public List<PartidaGuardada> cargarPartidasDetalladas() {
        asegurarFichero();
        try {
            List<PartidaGuardada> partidas = new ArrayList<>();
            for (String linea : Files.readAllLines(fichero, StandardCharsets.UTF_8)) {
                if (!linea.isBlank()) {
                    partidas.add(convertir(linea));
                }
            }
            return Collections.unmodifiableList(partidas);
        } catch (IOException | RuntimeException excepcion) {
            if (excepcion instanceof IllegalStateException) {
                throw (IllegalStateException) excepcion;
            }
            throw new IllegalStateException("No se pudo leer el historial desde " + fichero, excepcion);
        }
    }

    public Path getFichero() {
        return fichero;
    }

    private PartidaGuardada convertir(String linea) {
        String[] datos = linea.split("\\|", -1);
        if (datos.length != 5 && datos.length != 6) {
            throw new IllegalStateException("Formato inválido en el historial: " + linea);
        }
        try {
            Jugador jugadorX = new Jugador(datos[0], 'X', true);
            Jugador jugadorO = new Jugador(datos[1], 'O', true);
            Jugador ganador = datos[2].isBlank()
                    ? null
                    : datos[2].charAt(0) == 'X' ? jugadorX : datos[2].charAt(0) == 'O' ? jugadorO : null;
            if (!datos[2].isBlank() && ganador == null) {
                throw new IllegalStateException("Ganador inválido en el historial: " + linea);
            }
            ResultadoPartida resultado = new ResultadoPartida(jugadorX, jugadorO, ganador,
                    Integer.parseInt(datos[3]), LocalDateTime.parse(datos[4]));
            List<Movimiento> movimientos = datos.length == 6
                    ? deserializarMovimientos(datos[5], jugadorX, jugadorO)
                    : List.of();
            return new PartidaGuardada(resultado, movimientos);
        } catch (RuntimeException excepcion) {
            throw new IllegalStateException("Formato inválido en el historial: " + linea, excepcion);
        }
    }

    private String serializarMovimientos(List<Movimiento> movimientos) {
        List<String> datos = new ArrayList<>();
        for (Movimiento movimiento : movimientos) {
            datos.add(movimiento.getFila() + "," + movimiento.getColumna() + ","
                    + movimiento.getJugador().getSimbolo());
        }
        return String.join(";", datos);
    }

    private List<Movimiento> deserializarMovimientos(String datos, Jugador jugadorX, Jugador jugadorO) {
        if (datos.isBlank()) {
            return List.of();
        }
        List<Movimiento> movimientos = new ArrayList<>();
        for (String dato : datos.split(";")) {
            String[] partes = dato.split(",");
            if (partes.length != 3) {
                throw new IllegalStateException("Movimiento inválido: " + dato);
            }
            int fila = Integer.parseInt(partes[0]);
            int columna = Integer.parseInt(partes[1]);
            Jugador jugador = switch (partes[2]) {
                case "X" -> jugadorX;
                case "O" -> jugadorO;
                default -> throw new IllegalStateException("Símbolo inválido: " + partes[2]);
            };
            if (fila < 0 || fila > 2 || columna < 0 || columna > 2) {
                throw new IllegalStateException("Coordenadas inválidas: " + dato);
            }
            movimientos.add(new Movimiento(fila, columna, jugador));
        }
        return movimientos;
    }

    private void asegurarFichero() {
        try {
            Path padre = fichero.toAbsolutePath().getParent();
            if (padre != null) {
                Files.createDirectories(padre);
            }
            if (Files.notExists(fichero)) {
                Files.createFile(fichero);
            }
        } catch (IOException excepcion) {
            throw new IllegalStateException("No se pudo crear el fichero de historial " + fichero, excepcion);
        }
    }
}