package com.tresenraya.modelo;

public enum Dificultad {
    FACIL,
    MEDIA,
    DIFICIL
}
