package com.tresenraya.interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import com.tresenraya.interfaz.componentes.PanelTablero;
import com.tresenraya.modelo.Movimiento;
import com.tresenraya.persistencia.PartidaGuardada;
import com.tresenraya.persistencia.ResultadoPartida;

public class VentanaPartidaCargada extends JFrame {
    private final PartidaGuardada partidaGuardada;
    private final PanelTablero panelTablero = new PanelTablero();
    private final JLabel estado = new JLabel();

    public VentanaPartidaCargada(PartidaGuardada partidaGuardada) {
        super("Partida terminada");
        if (partidaGuardada == null) {
            throw new IllegalArgumentException("La partida guardada no puede ser nula");
        }
        this.partidaGuardada = partidaGuardada;
        construirVentana();
        mostrarPartida();
    }

    private void construirVentana() {
        ResultadoPartida resultado = partidaGuardada.getResultado();
        JPanel panelPrincipal = new JPanel(new BorderLayout(8, 8));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel informacion = new JPanel(new GridLayout(6, 1, 3, 3));
        for (String texto : new String[] {
                "Jugador X: " + resultado.getJugadorX().getNombre(),
                "Jugador O: " + resultado.getJugadorO().getNombre(),
                "Ganador: " + textoGanador(resultado),
                "Movimientos: " + resultado.getNumeroMovimientos(),
                "Fecha: " + resultado.getFecha()}) {
            JLabel etiqueta = new JLabel(texto);
            etiqueta.setFont(etiqueta.getFont().deriveFont(14f));
            informacion.add(etiqueta);
        }
        estado.setFont(estado.getFont().deriveFont(Font.BOLD, 14f));
        informacion.add(estado);
        panelPrincipal.add(informacion, BorderLayout.NORTH);
        panelPrincipal.add(panelTablero, BorderLayout.CENTER);
        setContentPane(panelPrincipal);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(460, 580);
        setMinimumSize(new Dimension(420, 520));
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void mostrarPartida() {
        char[][] tablero = new char[3][3];
        if (!partidaGuardada.tieneMovimientos()) {
            estado.setText("Estado final: movimientos no disponibles para reconstruir el tablero.");
            panelTablero.mostrarTablero(tablero);
            deshabilitarTablero();
            return;
        }
        try {
            for (Movimiento movimiento : partidaGuardada.getMovimientos()) {
                if (movimiento.getFila() < 0 || movimiento.getFila() > 2
                        || movimiento.getColumna() < 0 || movimiento.getColumna() > 2
                        || tablero[movimiento.getFila()][movimiento.getColumna()] != '\0') {
                    throw new IllegalStateException("Los movimientos guardados no permiten reconstruir el tablero");
                }
                tablero[movimiento.getFila()][movimiento.getColumna()] = movimiento.getJugador().getSimbolo();
            }
            panelTablero.mostrarTablero(tablero);
            estado.setText("Estado final: partida terminada (solo lectura).");
        } catch (IllegalStateException excepcion) {
            estado.setText(excepcion.getMessage());
            panelTablero.mostrarTablero(new char[3][3]);
        }
        deshabilitarTablero();
    }

    private void deshabilitarTablero() {
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                panelTablero.getBoton(fila, columna).setEnabled(false);
            }
        }
    }

    private String textoGanador(ResultadoPartida resultado) {
        return resultado.getGanador() == null
                ? "Empate"
                : String.valueOf(resultado.getGanador().getSimbolo());
    }

    public PartidaGuardada getPartidaGuardada() {
        return partidaGuardada;
    }

    public PanelTablero getPanelTablero() {
        return panelTablero;
    }

    public JLabel getEstado() {
        return estado;
    }
}
