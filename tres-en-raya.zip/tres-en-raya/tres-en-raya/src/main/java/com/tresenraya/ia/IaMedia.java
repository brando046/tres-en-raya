package com.tresenraya.ia;

import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;

public class IaMedia implements InteligenciaArtificial {
	@Override
	public Movimiento decidirMovimiento(Partida partida) {
		IaUtilidades.validarPartida(partida);
		char[][] tablero = partida.tablero();
		char simbolo = partida.turnoActual().getSimbolo();
		char rival = simbolo == 'X' ? 'O' : 'X';

		Movimiento movimientoGanador = IaUtilidades.movimientoQueCompletaLinea(partida, tablero, simbolo);
		if (movimientoGanador != null) {
			return movimientoGanador;
		}
		Movimiento movimientoBloqueo = IaUtilidades.movimientoQueCompletaLinea(partida, tablero, rival);
		if (movimientoBloqueo != null) {
			return movimientoBloqueo;
		}
		return IaUtilidades.movimientoPreferido(partida, tablero);
	}
}
