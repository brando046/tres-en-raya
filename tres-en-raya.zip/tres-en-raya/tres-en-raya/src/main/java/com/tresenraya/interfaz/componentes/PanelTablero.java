package com.tresenraya.interfaz.componentes;

import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import java.awt.Color;

import com.tresenraya.util.Constantes;

public class PanelTablero extends JPanel {
	private final JButton[][] botones = new JButton[Constantes.TAMANO_TABLERO][Constantes.TAMANO_TABLERO];
	private int filaSeleccionada;
	private int columnaSeleccionada;

	public PanelTablero() {
		super(new GridLayout(Constantes.TAMANO_TABLERO, Constantes.TAMANO_TABLERO));
		setPreferredSize(new Dimension(390, 390));
		setFocusTraversalPolicyProvider(true);
		setFocusTraversalPolicy(new LayoutFocusTraversalPolicy());
		crearCasillas();
		actualizarSeleccion();
	}

	public void actualizarSeleccion(int fila, int columna) {
		validarCoordenadas(fila, columna);
		filaSeleccionada = fila;
		columnaSeleccionada = columna;
		actualizarSeleccion();
	}

	private void actualizarSeleccion() {
		Border bordeNormal = UIManager.getBorder("Button.border");
		Border bordeSeleccionado = BorderFactory.createLineBorder(new Color(0, 90, 180), 3);
		for (int fila = 0; fila < Constantes.TAMANO_TABLERO; fila++) {
			for (int columna = 0; columna < Constantes.TAMANO_TABLERO; columna++) {
				botones[fila][columna].setBorder(
						fila == filaSeleccionada && columna == columnaSeleccionada
								? bordeSeleccionado : bordeNormal);
			}
		}
	}

	public int getFilaSeleccionada() {
		return filaSeleccionada;
	}

	public int getColumnaSeleccionada() {
		return columnaSeleccionada;
	}

	private void crearCasillas() {
		for (int fila = 0; fila < Constantes.TAMANO_TABLERO; fila++) {
			for (int columna = 0; columna < Constantes.TAMANO_TABLERO; columna++) {
				JButton boton = new JButton();
				boton.setFocusable(true);
				boton.setFocusPainted(true);
				boton.setFont(boton.getFont().deriveFont(Font.BOLD, 42f));
				boton.setActionCommand(fila + "," + columna);
				boton.getAccessibleContext().setAccessibleName("Casilla " + (fila + 1) + ", " + (columna + 1));
				boton.getAccessibleContext().setAccessibleDescription("Casilla del tablero, fila "
						+ (fila + 1) + ", columna " + (columna + 1));
				botones[fila][columna] = boton;
				add(boton);
			}
		}
	}

	public JButton getBoton(int fila, int columna) {
		validarCoordenadas(fila, columna);
		return botones[fila][columna];
	}

	public void mostrarTablero(char[][] tablero) {
		validarTablero(tablero);
		for (int fila = 0; fila < Constantes.TAMANO_TABLERO; fila++) {
			for (int columna = 0; columna < Constantes.TAMANO_TABLERO; columna++) {
				char simbolo = tablero[fila][columna];
				botones[fila][columna].setText(simbolo == '\0' ? "" : String.valueOf(simbolo));
			}
		}
	}

	private void validarCoordenadas(int fila, int columna) {
		if (fila < 0 || fila >= Constantes.TAMANO_TABLERO
				|| columna < 0 || columna >= Constantes.TAMANO_TABLERO) {
			throw new IllegalArgumentException("Las coordenadas deben estar entre 0 y 2");
		}
	}

	private void validarTablero(char[][] tablero) {
		if (tablero == null || tablero.length != Constantes.TAMANO_TABLERO) {
			throw new IllegalArgumentException("El tablero debe ser de 3x3");
		}
		for (char[] fila : tablero) {
			if (fila == null || fila.length != Constantes.TAMANO_TABLERO) {
				throw new IllegalArgumentException("El tablero debe ser de 3x3");
			}
		}
	}
}
