package com.tresenraya.interfaz;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;

import com.tresenraya.persistencia.Historial;
import com.tresenraya.persistencia.PartidaGuardada;
import com.tresenraya.persistencia.ResultadoPartida;

public class VentanaHistorial extends JFrame {
    private final Historial historial;
    private final DefaultListModel<PartidaGuardada> modeloLista = new DefaultListModel<>();
    private final JList<PartidaGuardada> listaResultados = new JList<>(modeloLista);
    private final JLabel estado = new JLabel("", SwingConstants.CENTER);
    private final JLabel jugadorX = new JLabel();
    private final JLabel jugadorO = new JLabel();
    private final JLabel ganador = new JLabel();
    private final JLabel movimientos = new JLabel();
    private final JLabel fecha = new JLabel();
    private JButton botonVerPartida;
    private PartidaGuardada partidaSeleccionada;
    private VentanaPartidaCargada ventanaPartidaCargada;

    public VentanaHistorial(Historial historial) {
        super("Historial de partidas");
        if (historial == null) {
            throw new IllegalArgumentException("El historial no puede ser nulo");
        }
        this.historial = historial;
        initializeComponents();
        setupLayout();
        setupListeners();
        configurarVentana();
        cargarResultados();
    }

    private void initializeComponents() {
        listaResultados.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaResultados.setCellRenderer(new ResultadoRenderer());
        limpiarDetalle();
    }

    private void setupLayout() {
        JPanel panelPrincipal = new JPanel(new BorderLayout(8, 8));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        JLabel titulo = new JLabel("Partidas guardadas", SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 19f));
        panelPrincipal.add(titulo, BorderLayout.NORTH);
        listaResultados.setFont(listaResultados.getFont().deriveFont(14f));
        listaResultados.setFixedCellHeight(30);
        panelPrincipal.add(new JScrollPane(listaResultados), BorderLayout.CENTER);

        JPanel panelDetalle = new JPanel(new GridLayout(5, 1, 4, 4));
        panelDetalle.setBorder(BorderFactory.createTitledBorder("Partida seleccionada"));
        panelDetalle.add(jugadorX);
        panelDetalle.add(jugadorO);
        panelDetalle.add(ganador);
        panelDetalle.add(movimientos);
        panelDetalle.add(fecha);

        botonVerPartida = new JButton("Ver partida");
        botonVerPartida.setMnemonic('V');
        botonVerPartida.setFont(botonVerPartida.getFont().deriveFont(14f));
        botonVerPartida.setPreferredSize(new java.awt.Dimension(150, 42));
        botonVerPartida.setFocusable(true);
        botonVerPartida.setFocusPainted(true);
        listaResultados.getAccessibleContext().setAccessibleName("Lista de partidas guardadas");
        botonVerPartida.setEnabled(false);
        JPanel panelAcciones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelAcciones.add(botonVerPartida);

        JPanel panelInferior = new JPanel(new BorderLayout(4, 4));
        panelInferior.add(estado, BorderLayout.NORTH);
        panelInferior.add(panelDetalle, BorderLayout.CENTER);
        panelInferior.add(panelAcciones, BorderLayout.SOUTH);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);
        setContentPane(panelPrincipal);
        setFocusTraversalPolicyProvider(true);
        setFocusTraversalPolicy(new LayoutFocusTraversalPolicy());
    }

    private void setupListeners() {
        listaResultados.addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                partidaSeleccionada = listaResultados.getSelectedValue();
                mostrarResultado(partidaSeleccionada);
                botonVerPartida.setEnabled(partidaSeleccionada != null);
            }
        });
        botonVerPartida.addActionListener(event -> abrirPartidaSeleccionada());
    }

    public void cargarResultados() {
        modeloLista.clear();
        partidaSeleccionada = null;
        botonVerPartida.setEnabled(false);
        try {
            List<PartidaGuardada> resultados = historial.cargarPartidasDetalladas();
            for (PartidaGuardada resultado : resultados) {
                modeloLista.addElement(resultado);
            }
            if (resultados.isEmpty()) {
                estado.setText("No hay partidas guardadas.");
                limpiarDetalle();
            } else {
                estado.setText("Selecciona una partida para consultar sus datos.");
                listaResultados.setSelectedIndex(0);
            }
        } catch (IllegalStateException excepcion) {
            estado.setText(excepcion.getMessage());
            limpiarDetalle();
        }
    }

    private void abrirPartidaSeleccionada() {
        if (partidaSeleccionada == null) {
            return;
        }
        ventanaPartidaCargada = new VentanaPartidaCargada(partidaSeleccionada);
        ventanaPartidaCargada.setVisible(true);
    }

    private void mostrarResultado(PartidaGuardada partidaGuardada) {
        if (partidaGuardada == null) {
            limpiarDetalle();
            return;
        }
        ResultadoPartida resultado = partidaGuardada.getResultado();
        jugadorX.setText("Jugador X: " + resultado.getJugadorX().getNombre());
        jugadorO.setText("Jugador O: " + resultado.getJugadorO().getNombre());
        ganador.setText("Ganador: " + textoGanador(resultado));
        movimientos.setText("Movimientos: " + resultado.getNumeroMovimientos());
        fecha.setText("Fecha: " + resultado.getFecha());
        if (partidaGuardada.tieneMovimientos()) {
            estado.setText("Partida seleccionada. Pulsa Ver partida para consultar el tablero final.");
        } else {
            estado.setText("No existe información de movimientos para reconstruir el tablero final.");
        }
    }

    private void limpiarDetalle() {
        jugadorX.setText("Jugador X: -");
        jugadorO.setText("Jugador O: -");
        ganador.setText("Ganador: -");
        movimientos.setText("Movimientos: -");
        fecha.setText("Fecha: -");
    }

    private String textoGanador(ResultadoPartida resultado) {
        return resultado.getGanador() == null
                ? "Empate"
                : String.valueOf(resultado.getGanador().getSimbolo());
    }

    public JList<PartidaGuardada> getListaResultados() {
        return listaResultados;
    }

    public JButton getBotonVerPartida() {
        return botonVerPartida;
    }

    public VentanaPartidaCargada getVentanaPartidaCargada() {
        return ventanaPartidaCargada;
    }

    public JLabel getEstado() {
        return estado;
    }

    public JLabel getJugadorX() {
        return jugadorX;
    }

    public JLabel getJugadorO() {
        return jugadorO;
    }

    public JLabel getGanador() {
        return ganador;
    }

    public JLabel getMovimientos() {
        return movimientos;
    }

    public JLabel getFecha() {
        return fecha;
    }

    private void configurarVentana() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(680, 480);
        setMinimumSize(new java.awt.Dimension(580, 400));
        setLocationRelativeTo(null);
    }

    private class ResultadoRenderer extends DefaultListCellRenderer {
        @Override
        public java.awt.Component getListCellRendererComponent(JList<?> lista, Object valor, int indice,
                boolean seleccionado, boolean tieneFoco) {
            super.getListCellRendererComponent(lista, valor, indice, seleccionado, tieneFoco);
            PartidaGuardada partidaGuardada = (PartidaGuardada) valor;
            ResultadoPartida resultado = partidaGuardada.getResultado();
            setText("Ganador: " + textoGanador(resultado)
                    + " | Movimientos: " + resultado.getNumeroMovimientos()
                    + " | Fecha: " + resultado.getFecha());
            setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
            return this;
        }
    }
}
