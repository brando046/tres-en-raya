package com.tresenraya.interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Objects;
import java.util.function.Consumer;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.tresenraya.modelo.Dificultad;

public class VentanaDificultad extends JFrame {
	private final Consumer<Dificultad> alSeleccionar;
	private final Runnable alVolver;
	private final Dificultad dificultadInicial;
	private JLabel mensajeEstado;
	private Dificultad dificultadSeleccionada;
	private JButton botonVolver;

	public VentanaDificultad() {
		this(Dificultad.FACIL, dificultad -> { }, () -> { });
	}

	public VentanaDificultad(Consumer<Dificultad> alSeleccionar) {
		this(Dificultad.FACIL, alSeleccionar, () -> { });
	}

	public VentanaDificultad(Dificultad dificultadInicial, Consumer<Dificultad> alSeleccionar) {
		this(dificultadInicial, alSeleccionar, () -> { });
	}

	public VentanaDificultad(Consumer<Dificultad> alSeleccionar, Runnable alVolver) {
		this(Dificultad.FACIL, alSeleccionar, alVolver);
	}

	public VentanaDificultad(Dificultad dificultadInicial, Consumer<Dificultad> alSeleccionar,
			Runnable alVolver) {
		super("Seleccionar dificultad");
		this.dificultadInicial = Objects.requireNonNull(dificultadInicial, "La dificultad inicial no puede ser nula");
		this.alSeleccionar = Objects.requireNonNull(alSeleccionar, "El callback no puede ser nulo");
		this.alVolver = Objects.requireNonNull(alVolver, "La acción de volver no puede ser nula");
		initializeComponents();
		setupLayout();
		setupListeners();
		configurarVentana();
	}

	private void initializeComponents() {
		mensajeEstado = new JLabel("Elige una dificultad", SwingConstants.CENTER);
	}

	private void setupLayout() {
		JPanel panelPrincipal = new JPanel(new BorderLayout(12, 12));
		panelPrincipal.setPreferredSize(new Dimension(400, 300));
		panelPrincipal.setBorder(BorderFactory.createEmptyBorder(22, 28, 22, 28));

		JLabel titulo = new JLabel("Selecciona la dificultad", SwingConstants.CENTER);
		titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 20f));
		panelPrincipal.add(titulo, BorderLayout.NORTH);

		JButton botonFacil = crearBoton("Fácil", Dificultad.FACIL, 'F');
		JButton botonMedia = crearBoton("Media", Dificultad.MEDIA, 'M');
		JButton botonDificil = crearBoton("Difícil", Dificultad.DIFICIL, 'D');
		botonFacil.setToolTipText("Seleccionar dificultad Fácil");
		botonMedia.setToolTipText("Seleccionar dificultad Media");
		botonDificil.setToolTipText("Seleccionar dificultad Difícil");
		botonFacil.setSelected(dificultadInicial == Dificultad.FACIL);
		botonMedia.setSelected(dificultadInicial == Dificultad.MEDIA);
		botonDificil.setSelected(dificultadInicial == Dificultad.DIFICIL);
		for (JButton boton : new JButton[] {botonFacil, botonMedia, botonDificil}) {
			boton.setFont(boton.getFont().deriveFont(16f));
			boton.setPreferredSize(new Dimension(320, 48));
		}

		ButtonGroup grupoBotones = new ButtonGroup();
		grupoBotones.add(botonFacil);
		grupoBotones.add(botonMedia);
		grupoBotones.add(botonDificil);

		JPanel panelOpciones = new JPanel(new GridLayout(3, 1, 8, 8));
		panelOpciones.add(botonFacil);
		panelOpciones.add(botonMedia);
		panelOpciones.add(botonDificil);
		panelPrincipal.add(panelOpciones, BorderLayout.CENTER);
		botonVolver = new JButton("Volver");
		botonVolver.setMnemonic('V');
		botonVolver.setFocusable(true);
		botonVolver.setFocusPainted(true);
		botonVolver.setFont(botonVolver.getFont().deriveFont(15f));
		botonVolver.setPreferredSize(new Dimension(130, 42));
		JPanel panelInferior = new JPanel(new BorderLayout(6, 6));
		panelInferior.add(mensajeEstado, BorderLayout.NORTH);
		JPanel acciones = new JPanel();
		acciones.add(botonVolver);
		panelInferior.add(acciones, BorderLayout.SOUTH);
		panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

		setContentPane(panelPrincipal);
		setFocusTraversalPolicyProvider(true);
		setFocusTraversalPolicy(new LayoutFocusTraversalPolicy());
	}

	private JButton crearBoton(String texto, Dificultad dificultad, char mnemonic) {
		JButton boton = new JButton(texto);
		boton.setMnemonic(mnemonic);
		boton.setFocusable(true);
		boton.setFocusPainted(true);
		boton.getAccessibleContext().setAccessibleName("Dificultad " + texto);
		boton.addActionListener(event -> seleccionarDificultad(dificultad));
		return boton;
	}

	private void setupListeners() {
		getRootPane().setDefaultButton(null);
		botonVolver.addActionListener(event -> alVolver.run());
	}

	public void seleccionarDificultad(Dificultad dificultad) {
		dificultadSeleccionada = Objects.requireNonNull(dificultad, "La dificultad no puede ser nula");
		mensajeEstado.setText("Dificultad seleccionada: " + textoDe(dificultad));
		alSeleccionar.accept(dificultadSeleccionada);
	}

	public Dificultad getDificultadSeleccionada() {
		return dificultadSeleccionada;
	}

	public JButton getBotonVolver() {
		return botonVolver;
	}

	private String textoDe(Dificultad dificultad) {
		return switch (dificultad) {
			case FACIL -> "Fácil";
			case MEDIA -> "Media";
			case DIFICIL -> "Difícil";
		};
	}

	private void configurarVentana() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		pack();
		setMinimumSize(getSize());
		setLocationRelativeTo(null);
		setResizable(false);
	}
}
