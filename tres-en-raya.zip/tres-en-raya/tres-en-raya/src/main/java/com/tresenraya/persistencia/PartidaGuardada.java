package com.tresenraya.persistencia;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.tresenraya.modelo.Movimiento;

public class PartidaGuardada {
    private final ResultadoPartida resultado;
    private final List<Movimiento> movimientos;

    public PartidaGuardada(ResultadoPartida resultado, List<Movimiento> movimientos) {
        if (resultado == null || movimientos == null) {
            throw new IllegalArgumentException("El resultado y los movimientos son obligatorios");
        }
        this.resultado = resultado;
        this.movimientos = Collections.unmodifiableList(new ArrayList<>(movimientos));
    }

    public ResultadoPartida getResultado() {
        return resultado;
    }

    public List<Movimiento> getMovimientos() {
        return movimientos;
    }

    public boolean tieneMovimientos() {
        return !movimientos.isEmpty();
    }
}