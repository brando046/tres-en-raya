package com.tresenraya.interfaz.componentes;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.tresenraya.modelo.Dificultad;
import com.tresenraya.modelo.ModoJuego;

public class PanelInformacion extends JPanel {
	private final JLabel etiquetaModo = new JLabel();
	private final JLabel etiquetaJugadores = new JLabel();
	private final JLabel etiquetaTurno = new JLabel();
	private final JLabel etiquetaJugadas = new JLabel();
	private final JLabel etiquetaResultado = new JLabel();

	public PanelInformacion() {
		super(new GridLayout(5, 1, 4, 4));
		setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
		add(etiquetaModo);
		add(etiquetaJugadores);
		add(etiquetaTurno);
		add(etiquetaJugadas);
		add(etiquetaResultado);
		mostrarModo(ModoJuego.JUGADOR_VS_JUGADOR, null);
		mostrarJugadores("Jugador X", "Jugador O");
		actualizarTurno("-");
		actualizarNumeroJugadas(0);
		mostrarResultado("");
	}

	public void mostrarModo(ModoJuego modoJuego, Dificultad dificultad) {
		if (modoJuego == null) {
			throw new IllegalArgumentException("El modo de juego no puede ser nulo");
		}
		String textoModo = modoJuego == ModoJuego.JUGADOR_VS_JUGADOR
				? "Modo: JUGADOR VS JUGADOR"
				: "Modo: JUGADOR VS IA";
		if (modoJuego == ModoJuego.JUGADOR_VS_IA) {
			if (dificultad == null) {
				throw new IllegalArgumentException("La dificultad es obligatoria para jugar contra la IA");
			}
			textoModo += " | Dificultad: " + textoDe(dificultad);
		}
		etiquetaModo.setText(textoModo);
	}

	public void mostrarJugadores(String nombreX, String nombreO) {
		etiquetaJugadores.setText("Jugador X: " + nombreX + " | Jugador O: " + nombreO);
	}

	public void actualizarTurno(String turno) {
		etiquetaTurno.setText("Turno actual: " + (turno == null ? "-" : turno));
	}

	public void actualizarNumeroJugadas(int numeroJugadas) {
		if (numeroJugadas < 0) {
			throw new IllegalArgumentException("El numero de jugadas no puede ser negativo");
		}
		etiquetaJugadas.setText("Jugadas: " + numeroJugadas);
	}

	public void mostrarResultado(String resultado) {
		etiquetaResultado.setText(resultado == null || resultado.isBlank() ? "Resultado: -" : "Resultado: " + resultado);
	}

	private String textoDe(Dificultad dificultad) {
		return switch (dificultad) {
			case FACIL -> "Fácil";
			case MEDIA -> "Media";
			case DIFICIL -> "Difícil";
		};
	}

	public JLabel getEtiquetaModo() {
		return etiquetaModo;
	}

	public JLabel getEtiquetaJugadores() {
		return etiquetaJugadores;
	}

	public JLabel getEtiquetaTurno() {
		return etiquetaTurno;
	}

	public JLabel getEtiquetaJugadas() {
		return etiquetaJugadas;
	}

	public JLabel getEtiquetaResultado() {
		return etiquetaResultado;
	}
}
