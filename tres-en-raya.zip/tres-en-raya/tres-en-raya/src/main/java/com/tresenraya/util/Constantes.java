package com.tresenraya.util;

public final class Constantes {
    public static final int TAMANO_TABLERO = 3;
    public static final String TITULO_APLICACION = "Tres en Raya";

    private Constantes() {
    }
}
