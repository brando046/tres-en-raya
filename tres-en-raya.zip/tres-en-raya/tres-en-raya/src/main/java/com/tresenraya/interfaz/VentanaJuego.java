package com.tresenraya.interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import com.tresenraya.configuracion.Configuracion;
import com.tresenraya.ia.IaDificil;
import com.tresenraya.ia.IaFacil;
import com.tresenraya.ia.IaMedia;
import com.tresenraya.ia.InteligenciaArtificial;
import com.tresenraya.interfaz.componentes.PanelInformacion;
import com.tresenraya.interfaz.componentes.PanelTablero;
import com.tresenraya.modelo.Dificultad;
import com.tresenraya.modelo.Jugador;
import com.tresenraya.modelo.ModoJuego;
import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;
import com.tresenraya.persistencia.Historial;
import com.tresenraya.persistencia.HistorialConsola;
import com.tresenraya.persistencia.ResultadoPartida;
import com.tresenraya.util.Constantes;

public class VentanaJuego extends JFrame {
    private Partida partida;
    private final ModoJuego modoJuego;
    private final Dificultad dificultad;
    private final Jugador jugadorHumano;
    private final Jugador jugadorMaquina;
    private final InteligenciaArtificial inteligenciaArtificial;
    private final Historial historial;
    private PanelTablero panelTablero;
    private PanelInformacion panelInformacion;
    private JButton botonNuevaPartida;
    private JButton botonSalir;
    private boolean turnoIa;
    private ResultadoPartida resultadoRegistrado;
    private int filaSeleccionada;
    private int columnaSeleccionada;

    public VentanaJuego() {
        this(Dificultad.FACIL, new HistorialConsola());
    }

    public VentanaJuego(Dificultad dificultad) {
        this(dificultad, new HistorialConsola());
    }

    public VentanaJuego(Dificultad dificultad, Historial historial) {
        this(ModoJuego.JUGADOR_VS_IA, new Configuracion(), dificultad, historial);
    }

    public VentanaJuego(Configuracion configuracion, Dificultad dificultad, Historial historial) {
        this(ModoJuego.JUGADOR_VS_IA, configuracion, dificultad, historial);
    }

    public VentanaJuego(ModoJuego modoJuego, Configuracion configuracion, Dificultad dificultad,
            Historial historial) {
        this(crearPartida(configuracion, modoJuego), modoJuego, dificultad, historial);
    }

    public VentanaJuego(Partida partida) {
        this(partida, new HistorialConsola());
    }

    public VentanaJuego(Partida partida, Historial historial) {
        this(partida, ModoJuego.JUGADOR_VS_JUGADOR, null, historial);
    }

    public VentanaJuego(Partida partida, ModoJuego modoJuego, Dificultad dificultad, Historial historial) {
        super(Constantes.TITULO_APLICACION);
        if (partida == null) {
            throw new IllegalArgumentException("La partida no puede ser nula");
        }
        if (modoJuego == null) {
            throw new IllegalArgumentException("El modo de juego no puede ser nulo");
        }
        if (modoJuego == ModoJuego.JUGADOR_VS_IA && dificultad == null) {
            throw new IllegalArgumentException("La dificultad es obligatoria para jugar contra la IA");
        }
        if (modoJuego == ModoJuego.JUGADOR_VS_JUGADOR && dificultad != null) {
            throw new IllegalArgumentException("La dificultad no se utiliza en el modo Jugador vs Jugador");
        }
        this.partida = partida;
        this.modoJuego = modoJuego;
        this.dificultad = dificultad;
        this.jugadorHumano = modoJuego == ModoJuego.JUGADOR_VS_IA ? partida.jugadorX() : null;
        this.jugadorMaquina = modoJuego == ModoJuego.JUGADOR_VS_IA ? partida.jugadorO() : null;
        this.inteligenciaArtificial = modoJuego == ModoJuego.JUGADOR_VS_IA
            	? crearInteligencia(dificultad) : null;
        if (historial == null) {
            throw new IllegalArgumentException("El historial no puede ser nulo");
        }
        this.historial = historial;
        initializeComponents();
        setupLayout();
        setupListeners();
        setupKeyboardBindings();
        configurarVentana();
        actualizarVista();
        solicitarFocoTablero();
    }

    private static Partida crearPartida(Configuracion configuracion, ModoJuego modoJuego) {
        Configuracion config = configuracionValida(configuracion);
        if (modoJuego == null) {
        	throw new IllegalArgumentException("El modo de juego no puede ser nulo");
        }
        boolean jugadorOEsHumano = modoJuego == ModoJuego.JUGADOR_VS_JUGADOR;
        return new Partida(
        		new Jugador(config.getJugadorX(), 'X', true),
        		new Jugador(config.getJugadorO(), 'O', jugadorOEsHumano));
    }

    private static Configuracion configuracionValida(Configuracion configuracion) {
        if (configuracion == null) {
            throw new IllegalArgumentException("La configuración no puede ser nula");
        }
        return configuracion;
    }

    private InteligenciaArtificial crearInteligencia(Dificultad dificultad) {
        return switch (dificultad) {
            case FACIL -> new IaFacil();
            case MEDIA -> new IaMedia();
            case DIFICIL -> new IaDificil();
        };
    }

    private void initializeComponents() {
        panelTablero = new PanelTablero();
        panelInformacion = new PanelInformacion();
        botonNuevaPartida = new JButton("Nueva partida");
        botonSalir = new JButton("Volver al inicio");
        botonNuevaPartida.setMnemonic('N');
        botonSalir.setMnemonic('V');
        botonNuevaPartida.setFocusable(true);
        botonSalir.setFocusable(true);
        botonNuevaPartida.setFocusPainted(true);
        botonSalir.setFocusPainted(true);
        for (JButton boton : new JButton[] {botonNuevaPartida, botonSalir}) {
            boton.setFont(boton.getFont().deriveFont(Font.PLAIN, 15f));
            boton.setPreferredSize(new Dimension(150, 42));
        }
    }

    private void setupLayout() {
        JPanel panelPrincipal = new JPanel(new BorderLayout(8, 8));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        panelPrincipal.add(panelInformacion, BorderLayout.NORTH);
        panelPrincipal.add(panelTablero, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotones.add(botonNuevaPartida);
        panelBotones.add(botonSalir);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        setContentPane(panelPrincipal);
        setFocusTraversalPolicyProvider(true);
        setFocusTraversalPolicy(new LayoutFocusTraversalPolicy());
    }

    private void setupListeners() {
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                final int filaSeleccionada = fila;
                final int columnaSeleccionada = columna;
                panelTablero.getBoton(fila, columna).addActionListener(
                        event -> {
                            seleccionarCasilla(filaSeleccionada, columnaSeleccionada);
                            alPulsarCasilla(filaSeleccionada, columnaSeleccionada);
                        });
            }
        }
        botonNuevaPartida.addActionListener(event -> nuevaPartida());
        botonSalir.addActionListener(event -> dispose());
    }

    private void setupKeyboardBindings() {
        instalarAccionesTablero(panelTablero, JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                instalarAccionesTablero(panelTablero.getBoton(fila, columna), JComponent.WHEN_FOCUSED);
            }
        }
    }

    private void instalarAccionesTablero(JComponent componente, int condicionFoco) {
        var inputMap = componente.getInputMap(condicionFoco);
        var actionMap = componente.getActionMap();
        inputMap.put(KeyStroke.getKeyStroke("UP"), "seleccionar-arriba");
        inputMap.put(KeyStroke.getKeyStroke("DOWN"), "seleccionar-abajo");
        inputMap.put(KeyStroke.getKeyStroke("LEFT"), "seleccionar-izquierda");
        inputMap.put(KeyStroke.getKeyStroke("RIGHT"), "seleccionar-derecha");
        inputMap.put(KeyStroke.getKeyStroke("pressed SPACE"), "jugar-seleccionada");
        actionMap.put("seleccionar-arriba", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                moverSeleccion(-1, 0);
            }
        });
        actionMap.put("seleccionar-abajo", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                moverSeleccion(1, 0);
            }
        });
        actionMap.put("seleccionar-izquierda", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                moverSeleccion(0, -1);
            }
        });
        actionMap.put("seleccionar-derecha", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                moverSeleccion(0, 1);
            }
        });
        actionMap.put("jugar-seleccionada", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                alPulsarCasilla(filaSeleccionada, columnaSeleccionada);
            }
        });
    }

    private void moverSeleccion(int cambioFila, int cambioColumna) {
        filaSeleccionada = Math.max(0, Math.min(2, filaSeleccionada + cambioFila));
        columnaSeleccionada = Math.max(0, Math.min(2, columnaSeleccionada + cambioColumna));
        actualizarSeleccion();
    }

    private void seleccionarCasilla(int fila, int columna) {
        filaSeleccionada = fila;
        columnaSeleccionada = columna;
        actualizarSeleccion();
    }

    private void actualizarSeleccion() {
        panelTablero.actualizarSeleccion(filaSeleccionada, columnaSeleccionada);
    }

    private void solicitarFocoTablero() {
        SwingUtilities.invokeLater(() -> panelTablero.getBoton(filaSeleccionada, columnaSeleccionada)
                .requestFocusInWindow());
    }

    public void alPulsarCasilla(int fila, int columna) {
        if (partida.haTerminado() || turnoIa) {
            return;
        }
        if (modoJuego == ModoJuego.JUGADOR_VS_IA && partida.turnoActual() != jugadorHumano) {
            return;
        }
        try {
            partida.marcar(fila, columna);
            actualizarVista();
            if (modoJuego == ModoJuego.JUGADOR_VS_IA
            		&& !partida.haTerminado() && partida.turnoActual() == jugadorMaquina) {
                realizarMovimientoIa();
            }
        } catch (IllegalArgumentException | IllegalStateException excepcion) {
            actualizarVista();
        }
    }

    private void realizarMovimientoIa() {
        turnoIa = true;
        actualizarVista();
        try {
            Movimiento movimiento = inteligenciaArtificial.decidirMovimiento(partida);
            partida.marcar(movimiento.getFila(), movimiento.getColumna());
        } finally {
            turnoIa = false;
            actualizarVista();
        }
    }

    public void actualizarVista() {
        panelTablero.mostrarTablero(partida.tablero());
        panelInformacion.mostrarModo(modoJuego, dificultad);
        panelInformacion.mostrarJugadores(partida.jugadorX().getNombre(), partida.jugadorO().getNombre());
        Jugador turno = partida.turnoActual();
        panelInformacion.actualizarTurno(turno.getNombre() + " (" + turno.getSimbolo() + ")");
        panelInformacion.actualizarNumeroJugadas(partida.numeroMovimientos());

        if (partida.ganador() != null) {
            panelInformacion.mostrarResultado("Ganador: " + partida.ganador().getSimbolo());
        } else if (partida.hayEmpate()) {
            panelInformacion.mostrarResultado("Empate");
        } else {
            panelInformacion.mostrarResultado("");
        }
        registrarResultadoSiTermino();
        actualizarCasillasDisponibles();
    }

    private void registrarResultadoSiTermino() {
        if (!partida.haTerminado() || resultadoRegistrado != null) {
            return;
        }
        resultadoRegistrado = new ResultadoPartida(
                partida.jugadorX(), partida.jugadorO(), partida.ganador(), partida.numeroMovimientos());
        historial.guardar(resultadoRegistrado, partida.movimientos());
    }

    private void actualizarCasillasDisponibles() {
        boolean puedenPulsarse = !partida.haTerminado() && !turnoIa;
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                panelTablero.getBoton(fila, columna).setEnabled(puedenPulsarse);
            }
        }
    }

    private void nuevaPartida() {
        if (modoJuego == ModoJuego.JUGADOR_VS_IA) {
            partida = new Partida(
            		new Jugador(jugadorHumano.getNombre(), 'X', true),
            		new Jugador(jugadorMaquina.getNombre(), 'O', false));
        } else {
            partida.reiniciar();
        }
        turnoIa = false;
        resultadoRegistrado = null;
        filaSeleccionada = 0;
        columnaSeleccionada = 0;
        actualizarVista();
        solicitarFocoTablero();
    }

    public Partida getPartida() {
        return partida;
    }

    public Dificultad getDificultad() {
        return dificultad;
    }

    public ModoJuego getModoJuego() {
        return modoJuego;
    }

    public InteligenciaArtificial getInteligenciaArtificial() {
        return inteligenciaArtificial;
    }

    public Historial getHistorial() {
        return historial;
    }

    public ResultadoPartida getResultadoRegistrado() {
        return resultadoRegistrado;
    }

    public PanelTablero getPanelTablero() {
        return panelTablero;
    }

    public PanelInformacion getPanelInformacion() {
        return panelInformacion;
    }

    private void configurarVentana() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(520, 620);
        setLocationRelativeTo(null);
        setResizable(false);
    }
}
