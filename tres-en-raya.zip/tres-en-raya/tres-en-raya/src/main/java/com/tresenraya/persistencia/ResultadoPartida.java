package com.tresenraya.persistencia;

import java.time.LocalDateTime;

import com.tresenraya.modelo.Jugador;

public class ResultadoPartida {
	private final Jugador jugadorX;
	private final Jugador jugadorO;
	private final Jugador ganador;
	private final int numeroMovimientos;
	private final LocalDateTime fecha;

	public ResultadoPartida(Jugador jugadorX, Jugador jugadorO, Jugador ganador, int numeroMovimientos) {
		this(jugadorX, jugadorO, ganador, numeroMovimientos, LocalDateTime.now());
	}

	public ResultadoPartida(Jugador jugadorX, Jugador jugadorO, Jugador ganador,
			int numeroMovimientos, LocalDateTime fecha) {
		if (jugadorX == null || jugadorO == null || fecha == null) {
			throw new IllegalArgumentException("Los jugadores y la fecha son obligatorios");
		}
		if (numeroMovimientos < 0) {
			throw new IllegalArgumentException("El numero de movimientos no puede ser negativo");
		}
		this.jugadorX = jugadorX;
		this.jugadorO = jugadorO;
		this.ganador = ganador;
		this.numeroMovimientos = numeroMovimientos;
		this.fecha = fecha;
	}

	public Jugador getJugadorX() {
		return jugadorX;
	}

	public Jugador getJugadorO() {
		return jugadorO;
	}

	public Jugador getGanador() {
		return ganador;
	}

	public int getNumeroMovimientos() {
		return numeroMovimientos;
	}

	public LocalDateTime getFecha() {
		return fecha;
	}
}
