package com.tresenraya.modelo;

public enum ModoJuego {
	JUGADOR_VS_JUGADOR,
	JUGADOR_VS_IA
}
