package com.tresenraya.ia;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;

public class IaFacil implements InteligenciaArtificial {
	@Override
	public Movimiento decidirMovimiento(Partida partida) {
		IaUtilidades.validarPartida(partida);
		char[][] tablero = partida.tablero();
		List<int[]> casillasLibres = new ArrayList<>();
		for (int fila = 0; fila < 3; fila++) {
			for (int columna = 0; columna < 3; columna++) {
				if (tablero[fila][columna] == '\0') {
					casillasLibres.add(new int[] {fila, columna});
				}
			}
		}
		if (casillasLibres.isEmpty()) {
			throw new IllegalStateException("No quedan movimientos disponibles");
		}
		int[] posicion = casillasLibres.get(ThreadLocalRandom.current().nextInt(casillasLibres.size()));
		return new Movimiento(posicion[0], posicion[1], partida.turnoActual());
	}
}
