package com.tresenraya.persistencia;

import java.util.List;

import com.tresenraya.modelo.Movimiento;

public interface Historial {
	void guardar(ResultadoPartida resultado);

	void guardar(ResultadoPartida resultado, List<Movimiento> movimientos);

	List<ResultadoPartida> cargarPartidas();

	List<ResultadoPartida> obtenerHistorial();

	List<PartidaGuardada> cargarPartidasDetalladas();
}
