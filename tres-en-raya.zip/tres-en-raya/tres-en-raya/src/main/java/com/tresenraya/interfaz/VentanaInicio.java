package com.tresenraya.interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Objects;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.tresenraya.configuracion.Configuracion;
import com.tresenraya.modelo.Dificultad;
import com.tresenraya.modelo.ModoJuego;
import com.tresenraya.persistencia.Historial;
import com.tresenraya.persistencia.HistorialFichero;

public class VentanaInicio extends JFrame {
	private final JLabel mensajeEstado = new JLabel("Selecciona una opción", SwingConstants.CENTER);
	private final Historial historial;
	private final Configuracion configuracion = new Configuracion();
	private JButton botonNuevaPartida;
	private JButton botonCargarPartida;
	private JButton botonConfiguracion;
	private JButton botonSalir;
	private VentanaModoJuego ventanaModoJuego;
	private VentanaDificultad ventanaDificultad;
	private VentanaConfiguracion ventanaConfiguracion;
	private VentanaJuego ventanaJuego;
	private VentanaHistorial ventanaHistorial;

	public VentanaInicio() {
		this(new HistorialFichero());
	}

	public VentanaInicio(Historial historial) {
		super(com.tresenraya.util.Constantes.TITULO_APLICACION);
		this.historial = Objects.requireNonNull(historial, "El historial no puede ser nulo");
		initializeComponents();
		setupLayout();
		setupListeners();
		configurarVentana();
	}

	private void initializeComponents() {
		botonNuevaPartida = new JButton("Nueva partida");
		botonCargarPartida = new JButton("Cargar partida");
		botonConfiguracion = new JButton("Configuración");
		botonSalir = new JButton("Salir");

		botonNuevaPartida.setMnemonic('N');
		botonCargarPartida.setMnemonic('A');
		botonConfiguracion.setMnemonic('C');
		botonSalir.setMnemonic('S');
		botonNuevaPartida.setToolTipText("Iniciar una nueva partida");
		botonCargarPartida.setToolTipText("Consultar partidas guardadas");
		botonConfiguracion.setToolTipText("Editar los nombres de los jugadores");
		botonSalir.setToolTipText("Cerrar la aplicación");
		for (JButton boton : new JButton[] {botonNuevaPartida, botonCargarPartida, botonConfiguracion, botonSalir}) {
			boton.setFocusable(true);
			boton.setFocusPainted(true);
			boton.setFont(boton.getFont().deriveFont(Font.PLAIN, 17f));
			boton.setPreferredSize(new Dimension(340, 50));
			boton.setMinimumSize(new Dimension(300, 46));
			boton.setMaximumSize(new Dimension(360, 52));
			boton.setMargin(new Insets(10, 18, 10, 18));
			boton.setOpaque(true);
			boton.setBackground(Color.WHITE);
			boton.setBorder(BorderFactory.createCompoundBorder(
					BorderFactory.createLineBorder(new Color(200, 210, 222)),
					BorderFactory.createEmptyBorder(8, 16, 8, 16)));
			boton.addMouseListener(new java.awt.event.MouseAdapter() {
				@Override
				public void mouseEntered(java.awt.event.MouseEvent event) {
					boton.setBackground(new Color(232, 240, 250));
				}

				@Override
				public void mouseExited(java.awt.event.MouseEvent event) {
					boton.setBackground(Color.WHITE);
				}
			});
		}
	}

	private void setupLayout() {
		JPanel panelPrincipal = new JPanel(new BorderLayout(16, 12));
		panelPrincipal.setPreferredSize(new Dimension(530, 460));
		panelPrincipal.setBackground(new Color(246, 248, 251));
		panelPrincipal.setBorder(BorderFactory.createEmptyBorder(22, 28, 18, 28));

		JLabel titulo = new JLabel(com.tresenraya.util.Constantes.TITULO_APLICACION, SwingConstants.CENTER);
		titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 32f));
		titulo.setForeground(new Color(35, 51, 72));
		titulo.setBorder(BorderFactory.createEmptyBorder(4, 0, 12, 0));
		titulo.setOpaque(false);
		panelPrincipal.add(titulo, BorderLayout.NORTH);

		JPanel panelBotones = new JPanel();
		panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.Y_AXIS));
		panelBotones.setOpaque(false);
		panelBotones.add(Box.createVerticalGlue());
		for (JButton boton : new JButton[] {botonNuevaPartida, botonCargarPartida,
				botonConfiguracion, botonSalir}) {
			boton.setAlignmentX(CENTER_ALIGNMENT);
			panelBotones.add(boton);
			panelBotones.add(Box.createVerticalStrut(12));
		}
		panelBotones.add(Box.createVerticalGlue());
		panelPrincipal.add(panelBotones, BorderLayout.CENTER);

		JPanel panelInferior = new JPanel(new GridBagLayout());
		panelInferior.setOpaque(false);
		GridBagConstraints restricciones = new GridBagConstraints();
		restricciones.gridx = 0;
		restricciones.gridy = 0;
		restricciones.fill = GridBagConstraints.HORIZONTAL;
		restricciones.weightx = 1;
		restricciones.insets = new Insets(0, 0, 8, 0);
		mensajeEstado.setFont(mensajeEstado.getFont().deriveFont(Font.PLAIN, 16f));
		mensajeEstado.setForeground(new Color(55, 68, 83));
		panelInferior.add(mensajeEstado, restricciones);

		JLabel tituloAtajos = new JLabel("Atajos de teclado", SwingConstants.CENTER);
		tituloAtajos.setFont(tituloAtajos.getFont().deriveFont(Font.BOLD, 13f));
		restricciones.gridy++;
		restricciones.insets = new Insets(0, 0, 3, 0);
		panelInferior.add(tituloAtajos, restricciones);

		JPanel panelAtajos = new JPanel(new GridBagLayout());
		panelAtajos.setOpaque(false);
		GridBagConstraints atajo = new GridBagConstraints();
		atajo.gridx = 0;
		atajo.gridy = 0;
		atajo.anchor = GridBagConstraints.WEST;
		atajo.insets = new Insets(1, 12, 1, 24);
		panelAtajos.add(new JLabel("Alt + N: Nueva partida"), atajo);
		atajo.gridx = 1;
		panelAtajos.add(new JLabel("Alt + A: Cargar partida"), atajo);
		atajo.gridx = 0;
		atajo.gridy = 1;
		panelAtajos.add(new JLabel("Alt + C: Configuración"), atajo);
		atajo.gridx = 1;
		panelAtajos.add(new JLabel("Alt + S: Salir"), atajo);
		for (Component componente : panelAtajos.getComponents()) {
			componente.setFont(componente.getFont().deriveFont(Font.PLAIN, 13f));
		}
		restricciones.gridy++;
		restricciones.insets = new Insets(0, 0, 0, 0);
		panelInferior.add(panelAtajos, restricciones);
		panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

		setContentPane(panelPrincipal);
		setFocusTraversalPolicyProvider(true);
		setFocusTraversalPolicy(new LayoutFocusTraversalPolicy());
	}

	private void setupListeners() {
		botonNuevaPartida.addActionListener(event -> abrirNuevaPartida());
		botonCargarPartida.addActionListener(event -> abrirHistorial());
		botonConfiguracion.addActionListener(event -> abrirConfiguracion());
		botonSalir.addActionListener(event -> dispose());
		getRootPane().setDefaultButton(botonNuevaPartida);
	}

	private void abrirNuevaPartida() {
		if (ventanaModoJuego != null && ventanaModoJuego.isDisplayable()) {
			ventanaModoJuego.toFront();
			ventanaModoJuego.requestFocus();
			return;
		}
		ventanaModoJuego = new VentanaModoJuego(this::seleccionarModo, this::volverAlInicioDesdeModo);
		ventanaModoJuego.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent event) {
				if (ventanaJuego == null || !ventanaJuego.isVisible()) {
					setVisible(true);
				}
			}
		});
		ventanaModoJuego.setVisible(true);
		setVisible(false);
	}

	private void seleccionarModo(ModoJuego modoJuego) {
		ventanaModoJuego.setVisible(false);
		if (modoJuego == ModoJuego.JUGADOR_VS_JUGADOR) {
			abrirPartida(ModoJuego.JUGADOR_VS_JUGADOR, null);
			ventanaModoJuego.dispose();
			return;
		}
		ventanaDificultad = new VentanaDificultad(
				this::abrirPartidaConDificultad, this::volverAlSelectorModo);
		ventanaDificultad.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent event) {
				if (ventanaJuego == null || !ventanaJuego.isVisible()) {
					ventanaModoJuego.setVisible(true);
					ventanaModoJuego.toFront();
				}
			}
		});
		ventanaDificultad.setVisible(true);
	}

	private void abrirPartidaConDificultad(Dificultad dificultad) {
		abrirPartida(ModoJuego.JUGADOR_VS_IA, dificultad);
		ventanaDificultad.dispose();
		ventanaModoJuego.dispose();
	}

	private void abrirPartida(ModoJuego modoJuego, Dificultad dificultad) {
		ventanaJuego = new VentanaJuego(modoJuego, configuracion, dificultad, historial);
		ventanaJuego.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent event) {
				setVisible(true);
			}
		});
		ventanaJuego.setVisible(true);
	}

	private void volverAlSelectorModo() {
		if (ventanaDificultad != null && ventanaDificultad.isDisplayable()) {
			ventanaDificultad.dispose();
		}
		if (ventanaModoJuego != null && ventanaModoJuego.isDisplayable()) {
			ventanaModoJuego.setVisible(true);
			ventanaModoJuego.toFront();
			ventanaModoJuego.requestFocus();
		}
	}

	private void volverAlInicioDesdeModo() {
		if (ventanaModoJuego != null && ventanaModoJuego.isDisplayable()) {
			ventanaModoJuego.dispose();
		}
		setVisible(true);
		toFront();
	}

	private void abrirConfiguracion() {
		if (ventanaConfiguracion != null && ventanaConfiguracion.isDisplayable()) {
			ventanaConfiguracion.toFront();
			ventanaConfiguracion.requestFocus();
			return;
		}
		ventanaConfiguracion = new VentanaConfiguracion(configuracion,
				() -> mensajeEstado.setText("Configuración guardada"));
		ventanaConfiguracion.setVisible(true);
	}

	private void abrirHistorial() {
		if (ventanaHistorial != null && ventanaHistorial.isDisplayable()) {
			ventanaHistorial.toFront();
			ventanaHistorial.requestFocus();
			return;
		}
		ventanaHistorial = new VentanaHistorial(historial);
		ventanaHistorial.setVisible(true);
	}

	private void configurarVentana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setMinimumSize(new Dimension(500, 460));
		setLocationRelativeTo(null);
		setResizable(true);
	}

	public VentanaJuego getVentanaJuego() {
		return ventanaJuego;
	}

	public VentanaDificultad getVentanaDificultad() {
		return ventanaDificultad;
	}

	public VentanaModoJuego getVentanaModoJuego() {
		return ventanaModoJuego;
	}

	public VentanaHistorial getVentanaHistorial() {
		return ventanaHistorial;
	}

	public Configuracion getConfiguracion() {
		return configuracion;
	}

	public VentanaConfiguracion getVentanaConfiguracion() {
		return ventanaConfiguracion;
	}
}
