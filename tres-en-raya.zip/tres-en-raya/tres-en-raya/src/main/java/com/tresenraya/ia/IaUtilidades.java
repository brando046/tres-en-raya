package com.tresenraya.ia;

import com.tresenraya.modelo.Movimiento;
import com.tresenraya.modelo.Partida;

final class IaUtilidades {
    private static final int[][] ORDEN_BUSQUEDA = {
        {1, 1}, {0, 0}, {0, 2}, {2, 0}, {2, 2},
        {0, 1}, {1, 0}, {1, 2}, {2, 1}
    };

    private IaUtilidades() {
    }

    static void validarPartida(Partida partida) {
        if (partida == null) {
            throw new IllegalArgumentException("La partida no puede ser nula");
        }
        if (partida.haTerminado()) {
            throw new IllegalStateException("No se puede decidir un movimiento en una partida terminada");
        }
        if (partida.turnoActual() == null || !partida.turnoActual().esIa()) {
            throw new IllegalStateException("La IA solo puede jugar durante su turno");
        }
    }

    static Movimiento movimientoEnPrimeraCasillaLibre(Partida partida) {
        char[][] tablero = partida.tablero();
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                if (tablero[fila][columna] == '\0') {
                    return new Movimiento(fila, columna, partida.turnoActual());
                }
            }
        }
        throw new IllegalStateException("No quedan movimientos disponibles");
    }

    static Movimiento movimientoQueCompletaLinea(Partida partida, char[][] tablero, char simbolo) {
        for (int[] posicion : ORDEN_BUSQUEDA) {
            int fila = posicion[0];
            int columna = posicion[1];
            if (tablero[fila][columna] == '\0') {
                tablero[fila][columna] = simbolo;
                boolean gana = hayLinea(tablero, simbolo);
                tablero[fila][columna] = '\0';
                if (gana) {
                    return new Movimiento(fila, columna, partida.turnoActual());
                }
            }
        }
        return null;
    }

    static Movimiento movimientoPreferido(Partida partida, char[][] tablero) {
        for (int[] posicion : ORDEN_BUSQUEDA) {
            if (tablero[posicion[0]][posicion[1]] == '\0') {
                return new Movimiento(posicion[0], posicion[1], partida.turnoActual());
            }
        }
        throw new IllegalStateException("No quedan movimientos disponibles");
    }

    static boolean hayLinea(char[][] tablero, char simbolo) {
        for (int indice = 0; indice < 3; indice++) {
            if ((tablero[indice][0] == simbolo && tablero[indice][1] == simbolo && tablero[indice][2] == simbolo)
                    || (tablero[0][indice] == simbolo && tablero[1][indice] == simbolo && tablero[2][indice] == simbolo)) {
                return true;
            }
        }
        return (tablero[0][0] == simbolo && tablero[1][1] == simbolo && tablero[2][2] == simbolo)
                || (tablero[0][2] == simbolo && tablero[1][1] == simbolo && tablero[2][0] == simbolo);
    }

    static boolean hayCasillasLibres(char[][] tablero) {
        for (char[] fila : tablero) {
            for (char casilla : fila) {
                if (casilla == '\0') {
                    return true;
                }
            }
        }
        return false;
    }

    static int[][] ordenDeBusqueda() {
        return ORDEN_BUSQUEDA;
    }
}