package com.tresenraya.configuracion;

public class Configuracion {
	private String jugadorX = "Jugador X";
	private String jugadorO = "IA";

	public String getNombreJugadorX() {
		return jugadorX;
	}

	public void setNombreJugadorX(String nombreJugadorX) {
		this.jugadorX = textoValido(nombreJugadorX, "El nombre de X no puede estar vacío");
	}

	public String getNombreJugadorO() {
		return jugadorO;
	}

	public void setNombreJugadorO(String nombreJugadorO) {
		this.jugadorO = textoValido(nombreJugadorO, "El nombre de O no puede estar vacío");
	}

	public String getJugadorX() {
		return jugadorX;
	}

	public void setJugadorX(String jugadorX) {
		this.jugadorX = textoValido(jugadorX, "El nombre de X no puede estar vacío");
	}

	public String getJugadorO() {
		return jugadorO;
	}

	public void setJugadorO(String jugadorO) {
		this.jugadorO = textoValido(jugadorO, "El nombre de O no puede estar vacío");
	}

	private String textoValido(String texto, String mensaje) {
		if (texto == null || texto.isBlank()) {
			throw new IllegalArgumentException(mensaje);
		}
		return texto;
	}
}
