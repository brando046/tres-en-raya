# Boceto de zonas

Documento reservado para definir la distribución visual de las ventanas y sus componentes en una fase posterior.

En esta fase no se implementa ninguna ventana ni distribución gráfica.
