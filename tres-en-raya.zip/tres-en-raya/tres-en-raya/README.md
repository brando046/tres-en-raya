# Tres en raya

Proyecto Maven de Java para desarrollar un juego de tres en raya como proyecto de 2º DAM.

`Nueva partida` abre `VentanaModoJuego` y permite elegir `Jugador vs Jugador` o `Jugador vs IA`. En el modo local, dos personas comparten el equipo y alternan X y O, sin movimientos automáticos. En el modo contra IA, `VentanaDificultad` permite elegir Fácil, Media o Difícil; la selección activa `IaFacil`, `IaMedia` o `IaDificil` para esa partida. `Volver` desde el selector de dificultad permite cambiar de modo.

La opción `Configuración` permite editar los nombres de ambos jugadores; no guarda el modo ni la dificultad. Los nombres se mantienen al navegar y se aplican en cualquiera de los dos modos. Al volver de una partida se conserva la configuración.

Las partidas terminadas se guardan automáticamente y se consultan desde `Cargar partida`. Cada resultado conserva también los movimientos realizados para poder visualizar el tablero final.

Durante una partida se puede jugar con ratón o con teclado: las flechas mueven la selección por el tablero 3x3 y Espacio realiza la jugada seleccionada. La casilla activa se marca visualmente y los límites del tablero se respetan.

Las partidas se almacenan en `historial.txt` en la carpeta de ejecución. El fichero se crea automáticamente y conserva los resultados y movimientos entre ejecuciones. Desde `Cargar partida` se selecciona una entrada y se pulsa `Ver partida` para consultar el tablero final en modo solo lectura. La interfaz consulta el historial mediante `HistorialFichero`, sin leer el fichero directamente.

Para compilar y empaquetar:

```bash
mvn clean package
```

Para iniciar la aplicación desde la raíz del proyecto:

```bash
java -cp target/classes com.tresenraya.App
```

Las pruebas del proyecto están en `src/test/java`: `mvn clean test` ejecuta las pruebas de integración JUnit 5 y compila también los arneses Java con `main`. Los arneses pueden ejecutarse directamente o desde el IDE para verificar recorridos con Swing y Robot. Se probaron los dos modos, la rotación de turnos, las tres dificultades, los nombres, la navegación, el historial y la visualización de partidas cargadas.
